package swiss.owt.fhir.vault.interceptor;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.instance.model.api.IBaseOperationOutcome;
import org.hl7.fhir.r5.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import swiss.owt.fhir.vault.dto.FhirClaimDto;
import swiss.owt.fhir.vault.enumeration.SecuritySourceType;
import swiss.owt.fhir.vault.util.FhirContextUtil;
import swiss.owt.fhir.vault.util.JWTTokenUtil;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Component
public class FhirVaultAuditInterceptor {
    private static final Logger log = LoggerFactory.getLogger(FhirVaultAuditInterceptor.class);

    private static final IParser iParser;

    static {
        iParser = FhirContextUtil.getiParser().setPrettyPrint(true);
    }

    @Hook(Pointcut.SERVER_PROCESSING_COMPLETED_NORMALLY)
    public void successResponse(RequestDetails requestDetails, IBaseOperationOutcome iBaseOperationOutcome) {
        RequestDetailsWrapper requestDetailsWrapper = new RequestDetailsWrapper(requestDetails);
        if (requestDetailsWrapper.isIgnorePath()) {
            return;
        }

        AuditEvent auditEvent = buildAuditSuccessEvent(requestDetails, iBaseOperationOutcome);
        log.info("Success Response: {}", iParser.encodeResourceToString(auditEvent));
    }

    @Hook(Pointcut.SERVER_OUTGOING_FAILURE_OPERATIONOUTCOME)
    public void failureOutgoingOperationOutcome(RequestDetails requestDetails,
                                                IBaseOperationOutcome iBaseOperationOutcome) {

        RequestDetailsWrapper requestDetailsWrapper = new RequestDetailsWrapper(requestDetails);
        if (requestDetailsWrapper.isIgnorePath()) {
            return;
        }

        AuditEvent auditEvent = buildAuditFailEvent(requestDetails, iBaseOperationOutcome);
        log.info("Fail Request: {}", iParser.encodeResourceToString(auditEvent));
    }

    private AuditEvent buildAuditFailEvent(RequestDetails requestDetails, IBaseOperationOutcome iBaseOperationOutcome) {
        AuditEvent auditFailEvent = buildAuditEvent(requestDetails);
        setFailOutcome(auditFailEvent, iBaseOperationOutcome);
        return auditFailEvent;
    }

    private AuditEvent buildAuditSuccessEvent(RequestDetails requestDetails, IBaseOperationOutcome iBaseOperationOutcome) {
        AuditEvent auditSuccessEvent = buildAuditEvent(requestDetails);
        setSuccessOutcome(auditSuccessEvent, iBaseOperationOutcome);
        return auditSuccessEvent;
    }

    private void setFailOutcome(AuditEvent auditFailEvent, IBaseOperationOutcome iBaseOperationOutcome) {
        if (iBaseOperationOutcome instanceof OperationOutcome operationOutcome) {
            String code = getCodeFromIssues(operationOutcome.getIssue());
            String display = getDisplayFromIssues(operationOutcome.getIssue());
            setOutcome(auditFailEvent, code, display);
            return;
        }

        // Default
        OperationOutcome.IssueSeverity errorIssueSeverity = OperationOutcome.IssueSeverity.ERROR;
        setOutcome(auditFailEvent, errorIssueSeverity.toCode(), errorIssueSeverity.getDisplay());
    }

    private void setSuccessOutcome(AuditEvent auditSuccessEvent, IBaseOperationOutcome iBaseOperationOutcome) {
        if (iBaseOperationOutcome instanceof OperationOutcome operationOutcome) {
            String code = getCodeFromIssues(operationOutcome.getIssue());
            String display = getDisplayFromIssues(operationOutcome.getIssue());
            setOutcome(auditSuccessEvent, code, display);
            return;
        }

        // Default
        OperationOutcome.IssueSeverity successIssueSeverity = OperationOutcome.IssueSeverity.SUCCESS;
        setOutcome(auditSuccessEvent, successIssueSeverity.toCode(), successIssueSeverity.getDisplay());
    }

    private String getDisplayFromIssues(List<OperationOutcome.OperationOutcomeIssueComponent> issue) {
        if (CollectionUtils.isEmpty(issue)) {
            return "";
        }
        return issue.get(0).getSeverity().getDisplay();
    }

    private String getCodeFromIssues(List<OperationOutcome.OperationOutcomeIssueComponent> issue) {
        if (CollectionUtils.isEmpty(issue)) {
            return "";
        }
        return issue.get(0).getSeverity().toCode();
    }

    private void setOutcome(AuditEvent auditEvent, String code, String display) {
        auditEvent.getOutcome().getCode()
                .setSystem("http://terminology.hl7.org/CodeSystem/audit-event-outcome")
                .setCode(code)
                .setDisplay(display);
    }

    private AuditEvent buildAuditEvent(RequestDetails requestDetails) {
        AuditEvent auditEvent = new AuditEvent();
        setId(auditEvent, requestDetails);
        setCode(auditEvent, requestDetails);
        setCategory(auditEvent, requestDetails);
        setRestfulInteraction(auditEvent, requestDetails);
        setAction(auditEvent, requestDetails);
        auditEvent.setRecorded(new Date());
        setAgent(auditEvent, requestDetails);
        setSource(auditEvent, requestDetails);
        setEntity(auditEvent, requestDetails);
        return auditEvent;
    }

    private void setCode(AuditEvent auditEvent, RequestDetails requestDetails) {
        auditEvent.setCode(new CodeableConcept(new Coding().setCode(requestDetails.getRestOperationType().getCode())));
    }

    private void setAction(AuditEvent auditEvent, RequestDetails requestDetails) {
        RequestTypeEnum requestType = requestDetails.getRequestType();
        auditEvent.setAction(setAuditEventActionByRequestType(requestType));
    }

    private void setAgent(AuditEvent auditEvent, RequestDetails requestDetails) {
        AuditEvent.AuditEventAgentComponent auditEventAgentComponent = auditEvent.addAgent();
        Identifier whoIdentifier = auditEventAgentComponent.getWho().getIdentifier();
        FhirClaimDto jwtDto = JWTTokenUtil.parsingJwtToken(requestDetails);
        whoIdentifier.setValue(jwtDto.getAccountUrn());
    }

    private void setSource(AuditEvent auditEvent, RequestDetails requestDetails) {
        AuditEvent.AuditEventSourceComponent auditEventSourceComponent = auditEvent.getSource();
        Reference observer = auditEventSourceComponent.getObserver();

        observer.getIdentifier().setValue(requestDetails.getFhirServerBase());
        observer.setDisplay(requestDetails.getServerBaseForRequest());

        auditEventSourceComponent
                .addType()
                .addCoding()
                .setCode(SecuritySourceType.WEB_SERVER.getCode())
                .setDisplay(SecuritySourceType.WEB_SERVER.getDisplay())
                .setSystem("http://terminology.hl7.org/CodeSystem/security-source-type");
    }

    private void setEntity(AuditEvent auditEvent, RequestDetails requestDetails) {
        AuditEvent.AuditEventEntityComponent entity = auditEvent.addEntity();

        entity.getWhat().setReference(requestDetails.getRequestPath());
    }

    private void setRestfulInteraction(AuditEvent auditEvent, RequestDetails requestDetails) {
        RestOperationTypeEnum operationTypeEnum = requestDetails.getRestOperationType();
        if (Objects.isNull(operationTypeEnum)) {
            return;
        }
        auditEvent
                .getCode()
                .addCoding()
                .setSystem(RestOperationTypeEnum.VALUESET_IDENTIFIER)
                .setCode(operationTypeEnum.getCode())
                .setDisplay(operationTypeEnum.getCode());
    }

    private void setId(AuditEvent auditEvent, RequestDetails requestDetails) {
        auditEvent.setId(requestDetails.getRequestId());
    }

    private void setCategory(AuditEvent auditEvent, RequestDetails requestDetails) {
        String code = "rest";
        String display = "RESTful Operation";
        String system = "http://terminology.hl7.org/CodeSystem/audit-event-type";
        auditEvent.addCategory().addCoding()
                .setSystem(system)
                .setCode(code)
                .setDisplay(display);
    }

    private AuditEvent.AuditEventAction setAuditEventActionByRequestType(RequestTypeEnum requestTypeEnum) {
        switch (requestTypeEnum) {
            case GET:
                return AuditEvent.AuditEventAction.R;
            case POST:
                return AuditEvent.AuditEventAction.C;
            case PUT:
                return AuditEvent.AuditEventAction.U;
            case DELETE:
                return AuditEvent.AuditEventAction.D;
            default:
                return null;
        }
    }
}
