package swiss.owt.fhir.vault.evaluation.expression;

import org.hl7.fhir.instance.model.api.IBase;
import org.hl7.fhir.r5.model.BooleanType;
import swiss.owt.fhir.vault.util.FhirContextUtil;

public class FhirPathExpressionEvaluation {

    private FhirPathExpressionEvaluation() {
    }

    public static boolean evaluate(IBase theInput, String thePath) {
        return FhirContextUtil.getiFhirPath().evaluate(theInput, thePath, BooleanType.class)
                .stream()
                .findFirst()
                .orElseThrow()
                .booleanValue();
    }
}
