package swiss.owt.fhir.vault.validation;

import org.hl7.fhir.r5.model.Period;
import org.hl7.fhir.r5.model.Permission;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swiss.owt.fhir.vault.exception.FhirVaultException;
import swiss.owt.fhir.vault.wrapper.IBaseResourceWrapper;

import java.util.Date;

public class PermissionValidation {

    private static final Logger log = LoggerFactory.getLogger(PermissionValidation.class);

    private PermissionValidation() {
    }

    public static boolean isValid(Permission permission) {
        try {
            validateStatus(permission.getStatus());
            validatePeriod(permission.getValidity());
            validateProfile(permission);
        } catch (FhirVaultException e) {
            log.info("Invalid permission content[{}]", e.getMessage());
            return false;
        }
        return true;
    }

    private static void validateProfile(Permission permission) {
        boolean hasCaraProfile = new IBaseResourceWrapper(permission).hasProfileResourceAccessPolicy();

        if (!hasCaraProfile) {
            throw new FhirVaultException("No cara resource access policy profile");
        }
    }

    private static void validatePeriod(Period period) {
        if (period == null) {
            return;
        }

        Date currentDate = new Date();
        if (period.getStart() != null && currentDate.before(period.getStart())) {
            throw new FhirVaultException("Start date not before current date.");
        }

        if (period.getEnd() != null && currentDate.after(period.getEnd())) {
            throw new FhirVaultException("End date not after current date.");
        }
    }

    private static void validateStatus(Permission.PermissionStatus status) {
        if (Permission.PermissionStatus.ACTIVE != status) {
            throw new FhirVaultException("Invalid status " + status + " permission");
        }
    }
}
