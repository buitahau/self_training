package swiss.owt.fhir.vault.evaluation.rulecombining.impl;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.r5.model.CodeableConcept;

import java.util.Set;

public class DenyUnlessPermitEvaluation extends AbstractEvaluation {

    @Override
    public PolicyEnum makeDecision(Set<CodeableConcept> allows, Set<CodeableConcept> denies,
                                   RestOperationTypeEnum restOperation) {

        if (CollectionUtils.isEmpty(allows)) {
            return PolicyEnum.ALLOW;
        }

        if (isContainOperation(allows, restOperation)) {
            return PolicyEnum.ALLOW;
        }

        return PolicyEnum.DENY;
    }
}
