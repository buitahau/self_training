package swiss.owt.fhir.vault.wrapper;

import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Bundle;
import org.hl7.fhir.r5.model.OperationOutcome;

import java.util.List;

public class ResponseObjectWrapper extends IBaseResourceWrapper {

    public ResponseObjectWrapper(IBaseResource theResponseObject) {
        super(theResponseObject);
    }

    public void eliminateDenyResources(List<IBaseResource> denyResources) {
        if (CollectionUtils.isEmpty(denyResources)) {
            return;
        }

        if (isBundle()) {
            Bundle bundle = (Bundle) iBaseResource;
            removeDenyResources(bundle.getEntry(), denyResources);
            iBaseResource = bundle;
            return;
        }

        iBaseResource = null;
    }

    private void removeDenyResources(List<Bundle.BundleEntryComponent> entryComponents,
                                     List<IBaseResource> denyResources) {

        for (Bundle.BundleEntryComponent entry : entryComponents) {
            if (entry.getResource() != null && isInDenyResources(denyResources, entry.getResource())) {
                entry.setResource(null);

                Bundle.BundleEntryResponseComponent response = new Bundle.BundleEntryResponseComponent();
                response.setStatus("403 Forbidden");
                response.setOutcome(
                        new OperationOutcome()
                                .addIssue(
                                        new OperationOutcome.OperationOutcomeIssueComponent()
                                                .setSeverity(OperationOutcome.IssueSeverity.ERROR)
                                                .setCode(OperationOutcome.IssueType.EXCEPTION)
                                                .setDiagnostics("Access denied following access policy")));
                entry.setResponse(response);
            }
        }
    }

    private boolean isInDenyResources(List<IBaseResource> denyResources, IBaseResource resource) {
        return denyResources
                .stream()
                .anyMatch(denyResource -> isEqual(denyResource, resource));
    }

    private boolean isEqual(IBaseResource one, IBaseResource two) {
        return one.getIdElement().getIdPart().equals(two.getIdElement().getIdPart());
    }
}
