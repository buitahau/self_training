package swiss.owt.fhir.vault.constant;

import java.util.List;

public class FhirVaultConstant {

    private FhirVaultConstant() {
    }

    public static final String FHIR_VAULT_NAMESPACE_SYSTEM =
            "https://terminology.cara.ch/CodeSystem/fhirvault-namespace";

    public static final String PREFIX_NAMESPACE_SCOPE = "ns:";

    public static final String PREFIX_TOKEN_CLAIM_EXPRESSION = "token://claim";

    public static final String ROLE_SERVICE_ACCOUNT = "SERVICE_ACCOUNT";

    public static final String ROLE_VAULT_ADMINISTRATOR = "VAULT_ADMINISTRATOR";

    public static final String ROLE_VAULT_ITEM_ADMINISTRATOR = "VAULT_ITEM_ADMINISTRATOR";

    public static final List<String> PARTITIONING_PATHS = List.of("partition-management-create-partition",
            "partition-management-update-partition",
            "partition-management-delete-partition",
            "partition-management-read-partition",
            "partition-management-list-partitions");

    public static final String ERROR_MESSAGE_PRINCIPLE_ACCESS_POLICY =
            "Access denied following principle access policy";

    public static final String ERROR_MESSAGE_NAMESPACE_ACCESS_POLICY =
            "Access denied following namespace access policy";

    public static final String ERROR_MESSAGE_RESOURCE_ACCESS_POLICY = "Access denied following resource access policy";

    public static final String RULE_ACTIVITY_PRINCIPAL =
            "https://terminology.cara.ch/StructureDefinition/Permission#rule-activity-principal";

    public static final String LANGUAGE_FHIR_PATH = "text/fhirpath";

    public static final String CARA_RESOURCE_ACCESS_POLICY =
            "https://terminology.cara.ch/StructureDefinition/ResourceAccessPolicy";

    public static final String CARA_PREFIX_CLAIM_NAME = "cara:";

    public static final String TRANSACTIONAL_CODE = "transactional";

    public static final String CONSENT_CODE = "consent";

    public static final String PERMISSION_KIND = "https://terminology.cara.ch/CodeSystem/fhirvault-policy-kind";
}
