package swiss.owt.fhir.vault.evaluation.expression.operation.activity;

import javax.annotation.Nonnull;
import java.util.List;

public interface ComparisonQueryOperation {
    boolean compare(String expectedValue, @Nonnull List<String> actualValue);
}
