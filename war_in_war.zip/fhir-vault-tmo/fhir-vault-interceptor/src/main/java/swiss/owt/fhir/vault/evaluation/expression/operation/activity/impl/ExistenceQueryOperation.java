package swiss.owt.fhir.vault.evaluation.expression.operation.activity.impl;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.ComparisonQueryOperation;

import javax.annotation.Nonnull;
import java.util.List;

public class ExistenceQueryOperation implements ComparisonQueryOperation {

    @Override
    public boolean compare(String expectedValue, @Nonnull List<String> actualValue) {
        if (CollectionUtils.isEmpty(actualValue)) {
            return false;
        }

        return StringUtils.isNotBlank(actualValue.get(0));
    }
}
