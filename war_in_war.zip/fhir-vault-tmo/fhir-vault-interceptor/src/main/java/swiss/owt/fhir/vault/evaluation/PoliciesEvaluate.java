package swiss.owt.fhir.vault.evaluation;

import org.hl7.fhir.instance.model.api.IBaseResource;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

public interface PoliciesEvaluate {

    VerdictWrapper evaluate(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource);
}
