package swiss.owt.fhir.vault.evaluation.expression;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swiss.owt.fhir.vault.dto.FhirClaimDto;
import swiss.owt.fhir.vault.enumeration.SpecialCharacter;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.ComparisonQueryOperation;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.ContextQueryOperation;
import swiss.owt.fhir.vault.wrapper.ClaimTokenExpressionWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import java.util.Arrays;
import java.util.List;

public class ClaimTokenExpressionEvaluation {

    private static final Logger log = LoggerFactory.getLogger(ClaimTokenExpressionEvaluation.class);

    private ClaimTokenExpressionEvaluation() {
    }

    public static boolean evaluate(RequestDetailsWrapper requestDetailsWrapper, String expression) {
        return isValid(expression, requestDetailsWrapper.getClaim());
    }

    private static boolean isValid(String expressions, FhirClaimDto fhirClaimDto) {
        if (StringUtils.isEmpty(expressions)) return false;
        String[] expressionsArr = expressions.split(SpecialCharacter.SEMICOLON.getSymbol());
        return Arrays
                .stream(expressionsArr)
                .allMatch(expression -> evaluateClaimTokenExpression(expression, fhirClaimDto));
    }

    private static ContextQueryOperation getContextQueryOperation(ComparisonQueryOperation operation) {
        ContextQueryOperation contextQueryOperation = new ContextQueryOperation();
        contextQueryOperation.setComparisonQueryOperation(operation);
        return contextQueryOperation;
    }

    private static boolean evaluateClaimTokenExpression(String expression, FhirClaimDto fhirClaimDto) {
        try {
            ClaimTokenExpressionWrapper claimTokenExpressionWrapper = new ClaimTokenExpressionWrapper(expression);

            String claimName = claimTokenExpressionWrapper.getClaimName();
            List<String> actualValue = fhirClaimDto.getValueByType(claimName);

            ComparisonQueryOperation operation = claimTokenExpressionWrapper.getComparisonQueryOperation();
            String expectedValue = claimTokenExpressionWrapper.getExpectedValue();

            return getContextQueryOperation(operation).execute(expectedValue, actualValue);
        } catch (Exception e) {
            log.error("Error in evaluating the token expression " + expression, e);
            return false;
        }
    }
}
