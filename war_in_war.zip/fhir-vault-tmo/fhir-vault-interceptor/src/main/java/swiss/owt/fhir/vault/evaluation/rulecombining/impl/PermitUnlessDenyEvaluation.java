package swiss.owt.fhir.vault.evaluation.rulecombining.impl;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.hl7.fhir.r5.model.CodeableConcept;

import java.util.Set;

public class PermitUnlessDenyEvaluation extends AbstractEvaluation {

    @Override
    public PolicyEnum makeDecision(Set<CodeableConcept> allows, Set<CodeableConcept> denies,
                                   RestOperationTypeEnum restOperation) {

        if (isContainOperation(denies, restOperation)) {
            return PolicyEnum.DENY;
        }

        return PolicyEnum.ALLOW;
    }
}
