package swiss.owt.fhir.vault.evaluation.impl;

import swiss.owt.fhir.vault.evaluation.PoliciesEvaluate;

public abstract class AbstractPoliciesEvaluation implements PoliciesEvaluate {
}
