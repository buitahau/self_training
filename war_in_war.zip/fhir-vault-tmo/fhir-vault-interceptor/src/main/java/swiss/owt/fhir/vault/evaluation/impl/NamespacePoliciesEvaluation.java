package swiss.owt.fhir.vault.evaluation.impl;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.enumeration.Role;
import swiss.owt.fhir.vault.util.BundleUtil;
import swiss.owt.fhir.vault.validation.NamespacePoliciesMatrix;
import swiss.owt.fhir.vault.wrapper.IBaseResourceWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

public class NamespacePoliciesEvaluation extends AbstractPoliciesEvaluation {

    private static final Logger log = LoggerFactory.getLogger(NamespacePoliciesEvaluation.class);

    public VerdictWrapper evaluate(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {
        PolicyEnum policyEnum = makeDecision(requestDetailsWrapper, resource);
        VerdictWrapper verdictWrapper = new VerdictWrapper(policyEnum);

        if (verdictWrapper.isDeny()) {
            verdictWrapper.setErrorMessage(FhirVaultConstant.ERROR_MESSAGE_NAMESPACE_ACCESS_POLICY);
        }

        return verdictWrapper;
    }

    private PolicyEnum makeDecision(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {
        IBaseResourceWrapper resourceWrapper = new IBaseResourceWrapper(resource);

        if (resourceWrapper.isResourceAccessPolicy()) {
            return evaluateRAP(requestDetailsWrapper, resourceWrapper);
        }

        String namespace = resourceWrapper.getNamespace();
        if (StringUtils.isBlank(namespace)) {
            log.info("No namespace in resource.");
            return PolicyEnum.DENY;
        }

        Role role = requestDetailsWrapper.getRole(namespace);
        if (role == null) {
            log.info("No role.");
            return PolicyEnum.DENY;
        }

        RestOperationTypeEnum restOperationType = BundleUtil.getRestOperationTypeEnum(requestDetailsWrapper, resource);

        if (NamespacePoliciesMatrix.isAllowedPermission(role, restOperationType)) {
            return PolicyEnum.ALLOW;
        }

        return PolicyEnum.DENY;
    }

    private PolicyEnum evaluateRAP(RequestDetailsWrapper requestDetailsWrapper, IBaseResourceWrapper resourceWrapper) {
        String namespace = resourceWrapper.getNamespace();
        if (StringUtils.isBlank(namespace)) {
            log.info("No namespace in RAP.");
            return PolicyEnum.DENY;
        }
        return isManager(requestDetailsWrapper, namespace) ? PolicyEnum.ALLOW : PolicyEnum.DENY;
    }

    private boolean isManager(RequestDetailsWrapper requestDetailsWrapper, String namespace) {
        Role role = requestDetailsWrapper.getRole(namespace);
        return Role.MANAGER == role;
    }
}
