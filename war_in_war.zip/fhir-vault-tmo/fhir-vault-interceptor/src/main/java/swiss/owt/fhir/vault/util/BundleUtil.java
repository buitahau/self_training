package swiss.owt.fhir.vault.util;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Bundle;
import swiss.owt.fhir.vault.wrapper.IBaseResourceWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

public class BundleUtil {

    private BundleUtil() {
    }

    public static RestOperationTypeEnum getRestOperationTypeEnum(RequestDetailsWrapper requestDetailsWrapper,
                                                                 IBaseResource resource) {

        if (requestDetailsWrapper.isReadOperation()) {
            return RestOperationTypeEnum.READ;
        }

        if (requestDetailsWrapper.getTheRequestDetails().getResource() == null) {
            return requestDetailsWrapper.getTheRequestDetails().getRestOperationType();
        }

        IBaseResourceWrapper iBaseResourceWrapper = new IBaseResourceWrapper(
                requestDetailsWrapper
                        .getTheRequestDetails()
                        .getResource());

        if (!iBaseResourceWrapper.isBundle()) {
            return requestDetailsWrapper.getTheRequestDetails().getRestOperationType();
        }

        Bundle bundle = iBaseResourceWrapper.parseToBundle();

        for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
            if (StringUtils.equals(entry.getResource().getIdElement().getIdPart(),
                    resource.getIdElement().getIdPart())) {

                return parsingFrom(entry.getRequest().getMethod());
            }
        }

        return RestOperationTypeEnum.CREATE;
    }

    private static RestOperationTypeEnum parsingFrom(Bundle.HTTPVerb httpVerb) {
        switch (httpVerb) {
            case POST:
                return RestOperationTypeEnum.CREATE;
            case PUT:
                return RestOperationTypeEnum.UPDATE;
            case DELETE:
                return RestOperationTypeEnum.DELETE;
            default:
                return null;
        }
    }
}
