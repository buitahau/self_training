package swiss.owt.fhir.vault.wrapper;

import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.apache.commons.lang3.Validate;
import org.hl7.fhir.instance.model.api.IBaseResource;

public class VerdictWrapper {

    private IBaseResource resource;

    private PolicyEnum theDecision;

    private String errorMessage;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public VerdictWrapper(IBaseResource resource) {
        Validate.notNull(resource);
        this.resource = resource;
        this.theDecision = PolicyEnum.DENY;
    }

    public VerdictWrapper(PolicyEnum theDecision) {
        Validate.notNull(theDecision);
        this.theDecision = theDecision;
    }

    public boolean isDeny() {
        return theDecision == PolicyEnum.DENY;
    }

    public boolean isAllow() {
        return theDecision == PolicyEnum.ALLOW;
    }

    public boolean isOwner() {
        return isAllow();
    }

    public IBaseResource getResource() {
        return resource;
    }

    public VerdictWrapper theDecision(PolicyEnum theDecision) {
        Validate.notNull(theDecision);
        this.theDecision = theDecision;
        return this;
    }

    public VerdictWrapper resource(IBaseResource resource) {
        Validate.notNull(resource);
        this.resource = resource;
        return this;
    }
}
