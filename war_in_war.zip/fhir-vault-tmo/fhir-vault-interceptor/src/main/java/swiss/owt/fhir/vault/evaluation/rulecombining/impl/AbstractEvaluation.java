package swiss.owt.fhir.vault.evaluation.rulecombining.impl;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.r5.model.CodeableConcept;
import swiss.owt.fhir.vault.evaluation.rulecombining.RuleCombiningEvaluate;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import java.util.Set;

public abstract class AbstractEvaluation implements RuleCombiningEvaluate {

    public VerdictWrapper evaluate(Set<CodeableConcept> allows, Set<CodeableConcept> denies,
                                   RestOperationTypeEnum restOperation) {

        return new VerdictWrapper(makeDecision(allows, denies, restOperation));
    }

    abstract PolicyEnum makeDecision(Set<CodeableConcept> allows, Set<CodeableConcept> denies,
                                     RestOperationTypeEnum restOperation);

    protected boolean isContainOperation(Set<CodeableConcept> actions, RestOperationTypeEnum restOperation) {
        if (CollectionUtils.isEmpty(actions)) {
            return false;
        }

        return actions.stream()
                .anyMatch(action -> StringUtils.equalsIgnoreCase(action.getCodingFirstRep().getCode(),
                        restOperation.getCode()));
    }
}
