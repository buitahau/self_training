package swiss.owt.fhir.vault.validation;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import swiss.owt.fhir.vault.enumeration.Role;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class NamespacePoliciesMatrix {

    private static final Map<OperationByRoleKey, Boolean> permissionMap = new HashMap<>();

    static {
        // Role Manager
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.READ), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.VREAD), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.UPDATE), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.PATCH), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.DELETE), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.HISTORY_INSTANCE), true);

        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.CREATE), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.SEARCH_TYPE), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.HISTORY_TYPE), true);

        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.BATCH), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.TRANSACTION), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.HISTORY_SYSTEM), true);
        permissionMap.put(new OperationByRoleKey(Role.MANAGER, RestOperationTypeEnum.SEARCH_SYSTEM), true);

        //Role Contributor
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.READ), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.VREAD), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.UPDATE), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.PATCH), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.DELETE), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.HISTORY_INSTANCE), true);

        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.CREATE), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.SEARCH_TYPE), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.HISTORY_TYPE), true);

        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.BATCH), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.TRANSACTION), true);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.HISTORY_SYSTEM), false);
        permissionMap.put(new OperationByRoleKey(Role.CONTRIBUTOR, RestOperationTypeEnum.SEARCH_SYSTEM), false);

        //Role Reader
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.READ), true);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.VREAD), true);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.UPDATE), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.PATCH), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.DELETE), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.HISTORY_INSTANCE), true);

        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.CREATE), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.SEARCH_TYPE), true);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.HISTORY_TYPE), true);

        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.BATCH), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.TRANSACTION), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.HISTORY_SYSTEM), false);
        permissionMap.put(new OperationByRoleKey(Role.READER, RestOperationTypeEnum.SEARCH_SYSTEM), false);
    }

    private record OperationByRoleKey(Role role, RestOperationTypeEnum operationTypeEnum) {

        @Override
        public int hashCode() {
            int hash = 5;
            hash = 23 * hash + Objects.hashCode(this.operationTypeEnum);
            hash = 23 * hash + Objects.hashCode(this.role);
            return hash;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof OperationByRoleKey operationByRoleKey)) {
                return false;
            }
            return this.operationTypeEnum.equals(operationByRoleKey.operationTypeEnum) && this.role.equals(operationByRoleKey.role);
        }

    }

    public static boolean isAllowedPermission(Role role, RestOperationTypeEnum restOperationTypeEnum) {
        Boolean isAllowed = permissionMap.get(new OperationByRoleKey(role, restOperationTypeEnum));
        if (isAllowed == null) return false;
        return isAllowed;
    }
}
