package swiss.owt.fhir.vault.util;

import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.instance.model.api.IBaseCoding;
import org.hl7.fhir.instance.model.api.IBaseResource;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;

import java.util.Optional;

public class ResourceUtil {

    private ResourceUtil() {
    }

    private static Optional<? extends IBaseCoding> getFullNamespace(IBaseResource iBaseResource) {
        return iBaseResource.getMeta().getTag().stream()
                .filter(coding -> FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM.equals(coding.getSystem()))
                .findFirst();
    }

    public static String getNamespace(IBaseResource iBaseResource) {
        Optional<? extends IBaseCoding> namespaceOpt = getFullNamespace(iBaseResource);
        if (namespaceOpt.isEmpty()) {
            return StringUtils.EMPTY;
        }
        return namespaceOpt.get().getCode();
    }
}
