package swiss.owt.fhir.vault.util;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.fhirpath.IFhirPath;
import ca.uhn.fhir.parser.IParser;

public class FhirContextUtil {

    private static final IFhirPath iFhirPathR5;

    private static final IParser iParserR5;

    private FhirContextUtil() {
    }

    static {
        FhirContext ctxR5 = FhirContext.forR5Cached();
        iFhirPathR5 = ctxR5.newFhirPath();
        iParserR5 = ctxR5.newJsonParser();
    }

    public static IFhirPath getiFhirPath() {
        return iFhirPathR5;
    }

    public static IParser getiParser() {
        return iParserR5;
    }

    public static void init() {
        // not do anything because it's already in static block.
    }
}
