package swiss.owt.fhir.vault.evaluation.rulecombining;

import swiss.owt.fhir.vault.evaluation.rulecombining.impl.DenyUnlessPermitEvaluation;
import swiss.owt.fhir.vault.evaluation.rulecombining.impl.PermitUnlessDenyEvaluation;
import org.hl7.fhir.r5.model.Permission;
import swiss.owt.fhir.vault.exception.FhirVaultException;

public class RuleCombiningEvaluationFactory {

    private RuleCombiningEvaluationFactory() {
    }

    public static RuleCombiningEvaluate get(Permission.PermissionRuleCombining combiningType) {
        return switch (combiningType) {
            case DENYUNLESSPERMIT -> new DenyUnlessPermitEvaluation();
            case PERMITUNLESSDENY -> new PermitUnlessDenyEvaluation();
            default -> throw new FhirVaultException("Wrong combining type " + combiningType);
        };
    }

}
