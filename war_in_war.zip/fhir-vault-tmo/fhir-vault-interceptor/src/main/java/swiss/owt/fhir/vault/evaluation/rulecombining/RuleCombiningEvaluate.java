package swiss.owt.fhir.vault.evaluation.rulecombining;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.r5.model.CodeableConcept;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import java.util.Set;

public interface RuleCombiningEvaluate {
    VerdictWrapper evaluate(Set<CodeableConcept> allows, Set<CodeableConcept> denies, RestOperationTypeEnum restOperation);
}
