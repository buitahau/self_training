package swiss.owt.fhir.vault.dto;

import com.nimbusds.jwt.JWTClaimsSet;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;

import java.util.*;

public class FhirClaimDto {

    private String accountUrn;

    private List<String> scope;

    private List<String> caraRoles;

    private JWTClaimsSet claimsSet;

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public JWTClaimsSet getClaimsSet() {
        return claimsSet;
    }

    public void setClaimsSet(JWTClaimsSet claimsSet) {
        this.claimsSet = claimsSet;
    }

    public String getAccountUrn() {
        return accountUrn;
    }

    public void setAccountUrn(String accountUrn) {
        this.accountUrn = accountUrn;
    }

    @Override
    public String toString() {
        return "FHIRClaim{" +
                "accountUrn='" + accountUrn + '\'' +
                ", scope=" + scope + '\'' +
                ", caraRoles=" + caraRoles +
                '}';
    }

    public List<String> getCaraRoles() {
        return caraRoles;
    }

    public void setCaraRoles(List<String> caraRoles) {
        if (caraRoles == null) {
            this.caraRoles = new ArrayList<>();
            return;
        }
        this.caraRoles = caraRoles;
    }

    @SuppressWarnings("unchecked")
    public List<String> getValueByType(String fieldName) {
        Object value = getClaimValue(fieldName);

        if (value == null) {
            return new ArrayList<>();
        }

        if (value instanceof List<?>) {
            return (List<String>) value;
        }

        return List.of(value.toString());
    }

    private Object getClaimValue(String name) {
        Object value = claimsSet.getClaim(name);
        if (value != null) {
            return value;
        }
        return claimsSet.getClaim(FhirVaultConstant.CARA_PREFIX_CLAIM_NAME + name);
    }
}
