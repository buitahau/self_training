package swiss.owt.fhir.vault.wrapper;

import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import org.apache.commons.lang3.Validate;
import org.hl7.fhir.r5.model.Bundle;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.dto.FhirClaimDto;
import swiss.owt.fhir.vault.enumeration.Role;
import swiss.owt.fhir.vault.util.JWTTokenUtil;

import java.util.List;

public class RequestDetailsWrapper {

    private FhirClaimDto claim;

    private final RequestDetails theRequestDetails;

    public static final List<String> ignorePaths = List.of("metadata", "error");

    public RequestDetailsWrapper(RequestDetails theRequestDetails) {
        Validate.notNull(theRequestDetails);
        this.theRequestDetails = theRequestDetails;
    }

    public boolean isReadOperation() {
        return theRequestDetails.getRequestType() == RequestTypeEnum.GET || isBatchRequest();
    }

    private boolean isBatchRequest() {
        return theRequestDetails.getRequestType() == RequestTypeEnum.POST && isBatchPayload();
    }

    private boolean isBatchPayload() {
        IBaseResourceWrapper iBaseResourceWrapper = new IBaseResourceWrapper(theRequestDetails.getResource());
        if (!iBaseResourceWrapper.isBundle()) {
            return false;
        }

        return iBaseResourceWrapper.parseToBundle().getType() == Bundle.BundleType.BATCH;
    }

    public boolean isWriteOperation() {
        return !isReadOperation();
    }

    public FhirClaimDto getClaim() {
        if (claim != null) {
            return claim;
        }

        claim = JWTTokenUtil.parsingJwtToken(theRequestDetails);

        return claim;
    }

    public boolean checkPoliciesBasedOnPayload() {
        return (theRequestDetails.getRequestType() == RequestTypeEnum.POST && !isBatchRequest())
                || theRequestDetails.getRequestType() == RequestTypeEnum.PUT;
    }

    public RequestDetails getTheRequestDetails() {
        return theRequestDetails;
    }

    public boolean isPartitionOperation() {
        return FhirVaultConstant.PARTITIONING_PATHS
                .stream()
                .anyMatch(path -> theRequestDetails.getRequestPath().contains(path));
    }

    public boolean isVaultItemAdministrator() {
        return isServiceAccount() && hasRole(FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR);
    }

    public boolean isServiceAccount() {
        getClaim();
        return hasRole(FhirVaultConstant.ROLE_SERVICE_ACCOUNT);
    }

    public boolean isVaultAdministrator() {
        return isServiceAccount() && hasRole(FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR);
    }

    public boolean isOnlyVaultAdministrator() {
        return isVaultAdministrator() && !isVaultItemAdministrator();
    }

    public boolean isIgnorePath() {
        return ignorePaths.stream().anyMatch(path -> theRequestDetails.getRequestPath().contains(path));
    }

    public String getVaultIdentity() {
        return theRequestDetails.getTenantId();
    }

    private boolean hasRole(String role) {
        return claim.getCaraRoles().contains(role);
    }

    public Role getRole(String namespace) {
        getClaim();
        String prefix = buildPrefixScopeClaim(namespace);
        return claim.getScope()
                .stream()
                .filter(scope -> scope.startsWith(prefix))
                .findFirst()
                .map(scope -> Role.valueOf(scope.replace(prefix, "").toUpperCase()))
                .orElse(null);
    }

    private String buildPrefixScopeClaim(String namespace) {
        return FhirVaultConstant.PREFIX_NAMESPACE_SCOPE
                + namespace.replace(FhirVaultConstant.CARA_PREFIX_CLAIM_NAME, "")
                + ".";
    }
}
