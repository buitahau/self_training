package swiss.owt.fhir.vault.interceptor;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import ca.uhn.fhir.rest.server.exceptions.ForbiddenOperationException;
import ca.uhn.fhir.rest.server.interceptor.auth.AuthorizationInterceptor;
import ca.uhn.fhir.rest.server.interceptor.auth.IAuthRule;
import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Permission;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import swiss.owt.fhir.vault.enumeration.SpecialCharacter;
import swiss.owt.fhir.vault.evaluation.FhirVaultPoliciesEvaluation;
import swiss.owt.fhir.vault.util.FhirContextUtil;
import swiss.owt.fhir.vault.util.IAuthRuleUtil;
import swiss.owt.fhir.vault.wrapper.*;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class FhirVaultPoliciesInterceptor extends AuthorizationInterceptor {

    private static final Logger LOG = LoggerFactory.getLogger(FhirVaultPoliciesInterceptor.class);

    private IFhirResourceDao<Permission> permissionResourceDao;

    @Autowired
    public FhirVaultPoliciesInterceptor(IFhirResourceDao<Permission> permissionIFhirResourceDao) {
        FhirContextUtil.init();
        this.permissionResourceDao = permissionIFhirResourceDao;
    }

    @Override
    public void incomingRequestPreHandled(RequestDetails theRequest, Pointcut thePointcut) {
        RequestDetailsWrapper requestDetailsWrapper = new RequestDetailsWrapper(theRequest);

        if (requestDetailsWrapper.isIgnorePath()) {
            return;
        }

        // Read Operation
        if (requestDetailsWrapper.isReadOperation()) {
            return;
        }

        // Write Operation: Allow the request which can not be checked policies based on the payload, need fetch data from provider
        if (!requestDetailsWrapper.checkPoliciesBasedOnPayload()) {
            return;
        }

        // Write Operation: check the request which can be checked policies based on the payload
        checkPoliciesBasedOnPayload(requestDetailsWrapper);
    }

    @Override
    public List<IAuthRule> buildRuleList(RequestDetails theRequestDetails) {
        return IAuthRuleUtil.buildRulesToAllowAll();
    }

    @Hook(Pointcut.STORAGE_PRESTORAGE_RESOURCE_UPDATED)
    public void resourceUpdated(IBaseResource theOldResource, IBaseResource theNewResource, RequestDetails theRequest) {
        // Write operation: Check policies for resource updates using the PATCH method.
        checkPoliciesForUpdateOrDeleteResource(theRequest, theOldResource);
    }

    @Hook(Pointcut.STORAGE_PRESTORAGE_RESOURCE_DELETED)
    public void resourceDeleted(IBaseResource theResource, RequestDetails theRequest) {
        // Write operation: Check policies for resource updates using the DELETE method.
        checkPoliciesForUpdateOrDeleteResource(theRequest, theResource);
    }

    @Hook(Pointcut.SERVER_OUTGOING_RESPONSE)
    public void hookOutgoingResponse(RequestDetails theRequestDetails, IBaseResource theResponseObject,
                                     Pointcut thePointcut, ResponseDetails responseDetails) {

        RequestDetailsWrapper requestDetailsWrapper = new RequestDetailsWrapper(theRequestDetails);

        if (requestDetailsWrapper.isWriteOperation() || requestDetailsWrapper.checkPoliciesBasedOnPayload()
                || requestDetailsWrapper.isIgnorePath()) {
            return;
        }

        // Read operation: check response object
        ResponseObjectWrapper responseObjectWrapper = new ResponseObjectWrapper(theResponseObject);

        List<VerdictWrapper> denyVerdicts = getDenyVerdicts(requestDetailsWrapper,
                responseObjectWrapper.getResources());

        List<IBaseResource> denyResources = denyVerdicts
                .stream()
                .map(VerdictWrapper::getResource)
                .collect(Collectors.toList());

        responseObjectWrapper.eliminateDenyResources(denyResources);

        List<IBaseResource> allowResources = responseObjectWrapper.getResources();

        if (!responseObjectWrapper.isBundle() && CollectionUtils.isEmpty(allowResources)) {
            throwFhirVaultException(denyVerdicts);
        }

        theResponseObject = responseObjectWrapper.getFinalResponseResource();
        responseDetails.setResponseResource(theResponseObject);
    }

    private void checkPoliciesForUpdateOrDeleteResource(RequestDetails theRequestDetails,
                                                        IBaseResource theResource) {

        RequestDetailsWrapper requestDetailsWrapper = new RequestDetailsWrapper(theRequestDetails);

        if (requestDetailsWrapper.isReadOperation() || requestDetailsWrapper.checkPoliciesBasedOnPayload()
                || requestDetailsWrapper.isIgnorePath()) {
            return;
        }

        List<VerdictWrapper> denyVerdicts = getDenyVerdicts(requestDetailsWrapper,
                new IBaseResourceWrapper(theResource).getResources());

        List<IBaseResource> denyResources = denyVerdicts
                .stream()
                .map(VerdictWrapper::getResource)
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(denyResources)) {
            throwFhirVaultException(denyVerdicts);
        }
    }

    private void throwFhirVaultException(List<VerdictWrapper> denyVerdicts) {
        String errorMessage = collectErrorMessage(denyVerdicts);
        throw new ForbiddenOperationException(errorMessage);
    }

    private void checkPoliciesBasedOnPayload(RequestDetailsWrapper requestDetailsWrapper) {
        List<VerdictWrapper> denyVerdicts = getDenyVerdicts(requestDetailsWrapper,
                new IBaseResourceWrapper(requestDetailsWrapper.getTheRequestDetails().getResource()).getResources());

        List<IBaseResource> denyResources = denyVerdicts
                .stream()
                .map(VerdictWrapper::getResource)
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(denyResources)) {
            throwFhirVaultException(denyVerdicts);
        }
    }

    private String collectErrorMessage(List<VerdictWrapper> denyVerdicts) {
        return denyVerdicts.stream()
                .map(VerdictWrapper::getErrorMessage)
                .distinct()
                .collect(Collectors.joining(SpecialCharacter.COMMAS.getSymbol()));
    }

    private List<VerdictWrapper> getDenyVerdicts(RequestDetailsWrapper requestDetailsWrapper,
                                                 List<IBaseResource> resources) {

        return resources
                .stream()
                .map(resource -> new FhirVaultPoliciesEvaluation(
                        new PermissionResourceDaoWrapper(permissionResourceDao,
                                requestDetailsWrapper.getTheRequestDetails()))
                        .validatePolicies(requestDetailsWrapper, resource)
                        .resource(resource)
                )
                .filter(VerdictWrapper::isDeny)
                .collect(Collectors.toList());
    }
}
