package swiss.owt.fhir.vault.enumeration;

public enum Role {
    MANAGER, CONTRIBUTOR, READER
}
