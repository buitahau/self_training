package swiss.owt.fhir.vault.enumeration;

import javax.annotation.Nonnull;

public enum SecuritySourceType {

    WEB_SERVER("3", "Web Server", "Web Server process or thread.");

    private final String code;
    private final String display;
    private final String definition;

    SecuritySourceType(@Nonnull String code, String display, String definition) {
        this.code = code;
        this.display = display;
        this.definition = definition;
    }

    @Nonnull
    public String getCode() {
        return code;
    }

    public String getDisplay() {
        return display;
    }

    public String getDefinition() {
        return definition;
    }
}
