package swiss.owt.fhir.vault.enumeration;

import javax.annotation.Nonnull;

public enum SpecialCharacter {

    QUESTION_MARKS("?"),
    COLONS(":"),
    PERIOD("."),
    COMMAS(","),
    SEMICOLON(";"),
    EQUAL("=");

    private final String symbol;

    SpecialCharacter(@Nonnull String symbol) {
        this.symbol = symbol;
    }

    @Nonnull
    public String getSymbol() {
        return symbol;
    }
}
