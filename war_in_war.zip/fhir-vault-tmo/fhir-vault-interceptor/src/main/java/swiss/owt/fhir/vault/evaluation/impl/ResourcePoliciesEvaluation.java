package swiss.owt.fhir.vault.evaluation.impl;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.expression.ClaimTokenExpressionEvaluation;
import swiss.owt.fhir.vault.evaluation.expression.FhirPathExpressionEvaluation;
import swiss.owt.fhir.vault.evaluation.rulecombining.RuleCombiningEvaluationFactory;
import swiss.owt.fhir.vault.util.BundleUtil;
import swiss.owt.fhir.vault.wrapper.*;

import java.util.*;
import java.util.stream.Collectors;

public class ResourcePoliciesEvaluation extends AbstractPoliciesEvaluation {

    private static final Logger log = LoggerFactory.getLogger(ResourcePoliciesEvaluation.class);

    private PermissionResourceDaoWrapper permissionResourceDaoWrapper;

    public ResourcePoliciesEvaluation(PermissionResourceDaoWrapper permissionResourceDaoWrapper) {
        this.permissionResourceDaoWrapper = permissionResourceDaoWrapper;
    }

    public VerdictWrapper evaluate(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {
        VerdictWrapper transactionalChecked = evaluateTransactional(requestDetailsWrapper, resource);

        if (transactionalChecked.isDeny()) {
            log.info("Deny at transactional.");
            transactionalChecked.setErrorMessage(FhirVaultConstant.ERROR_MESSAGE_RESOURCE_ACCESS_POLICY);
            return transactionalChecked;
        }

        return transactionalChecked;
    }

    private VerdictWrapper evaluateConsent(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {
        String namespace = new IBaseResourceWrapper(resource).getNamespace();
        return evaluatePolicies(requestDetailsWrapper, resource,
                permissionResourceDaoWrapper.getConsentPermissions(namespace));
    }

    private VerdictWrapper evaluateTransactional(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {
        String namespace = new IBaseResourceWrapper(resource).getNamespace();
        return evaluatePolicies(requestDetailsWrapper, resource,
                permissionResourceDaoWrapper.getTransactionalPermissions(namespace));
    }

    private VerdictWrapper evaluatePolicies(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource,
                                            List<Permission> permissions) {

        if (CollectionUtils.isEmpty(permissions)) {
            log.info("No permissions.");
            return new VerdictWrapper(PolicyEnum.DENY);
        }
        return evaluate(requestDetailsWrapper, resource, permissions);
    }

    private VerdictWrapper evaluate(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource,
                                    List<Permission> permissions) {

        for (Permission permission : permissions) {
            List<Permission.RuleComponent> rules = getRules(permission, Enumerations.ConsentProvisionType.PERMIT);

            for (Permission.RuleComponent rule : rules) {

                boolean matchesPrincipal = matchesPrincipal(rule.getActivity(), requestDetailsWrapper);

                if (!matchesPrincipal) {
                    continue;
                }

                boolean matchesAction = evaluate(permission.getCombining(), getActions(rule), requestDetailsWrapper,
                        resource)
                        .isAllow();

                if (!matchesAction) {
                    continue;
                }

                boolean matchesData = matchesData(rule.getData(), resource);

                if (matchesData) {
                    return new VerdictWrapper(PolicyEnum.ALLOW);
                }
            }
        }

        return new VerdictWrapper(PolicyEnum.DENY);
    }

    private List<Permission.RuleComponent> getRules(Permission permission, Enumerations.ConsentProvisionType type) {
        return permission.getRule()
                .stream()
                .filter(ruleComponent -> ruleComponent.getType() == type)
                .toList();
    }

    private Set<CodeableConcept> getActions(Permission.RuleComponent rule) {
        return rule.getActivity().stream()
                .flatMap(activity -> activity.getAction().stream())
                .collect(Collectors.toSet());
    }

    private boolean matchesPrincipal(List<Permission.RuleActivityComponent> activities,
                                     RequestDetailsWrapper requestDetailsWrapper) {

        if (CollectionUtils.isEmpty(activities)) {
            return false;
        }

        return activities.stream()
                .anyMatch(activity -> isMatchExtensions(activity.getExtension(), requestDetailsWrapper));
    }

    private boolean isMatchExtensions(List<Extension> extensions, RequestDetailsWrapper requestDetailsWrapper) {
        if (CollectionUtils.isEmpty(extensions)) {
            return true;
        }

        return extensions.stream()
                .filter(extension -> FhirVaultConstant.RULE_ACTIVITY_PRINCIPAL.equalsIgnoreCase(extension.getUrl()))
                .anyMatch(extension -> ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper,
                        extension.getValue().primitiveValue()));
    }

    private boolean matchesData(List<Permission.RuleDataComponent> datas, IBaseResource resource) {
        if (CollectionUtils.isEmpty(datas)) {
            return true;
        }

        return datas.stream()
                .filter(data -> FhirVaultConstant.LANGUAGE_FHIR_PATH.equalsIgnoreCase(data.getExpression().getLanguage()))
                .anyMatch(data -> FhirPathExpressionEvaluation.evaluate(resource, data.getExpression().getExpression()));
    }

    private VerdictWrapper evaluate(Permission.PermissionRuleCombining combining, Set<CodeableConcept> allows,
                                    RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {

        RestOperationTypeEnum restOperationType = BundleUtil.getRestOperationTypeEnum(requestDetailsWrapper, resource);
        return RuleCombiningEvaluationFactory.get(combining).evaluate(allows, null, restOperationType);
    }
}
