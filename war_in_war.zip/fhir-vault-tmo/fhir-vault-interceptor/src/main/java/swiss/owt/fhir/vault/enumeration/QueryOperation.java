package swiss.owt.fhir.vault.enumeration;

public enum QueryOperation {
    EQUAL, INCLUDE, EXIST, STARTWITH
}
