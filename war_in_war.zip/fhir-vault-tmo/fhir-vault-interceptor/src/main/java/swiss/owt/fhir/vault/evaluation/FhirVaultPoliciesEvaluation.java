package swiss.owt.fhir.vault.evaluation;

import ca.uhn.fhir.rest.server.interceptor.auth.PolicyEnum;
import org.hl7.fhir.instance.model.api.IBaseResource;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.impl.NamespacePoliciesEvaluation;
import swiss.owt.fhir.vault.evaluation.impl.ResourcePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.PermissionResourceDaoWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

public class FhirVaultPoliciesEvaluation {

    private final PermissionResourceDaoWrapper permissionResourceDaoWrapper;

    public FhirVaultPoliciesEvaluation(PermissionResourceDaoWrapper permissionResourceDaoWrapper) {
        this.permissionResourceDaoWrapper = permissionResourceDaoWrapper;
    }

    public VerdictWrapper validatePolicies(RequestDetailsWrapper requestDetailsWrapper, IBaseResource resource) {

        if (requestDetailsWrapper.isPartitionOperation()) {
            return validateVaultAdministrator(requestDetailsWrapper);
        }

        // Deny if the request is not a partition operation and the user has only the CARA Vault Administrator Role
        if (requestDetailsWrapper.isOnlyVaultAdministrator()) {
            return getDenyPrincipleVerdictWrapper();
        }

        VerdictWrapper namespaceEvaluation = new NamespacePoliciesEvaluation()
                .evaluate(requestDetailsWrapper, resource);

        if (namespaceEvaluation.isDeny()) {
            return namespaceEvaluation;
        }

        if (requestDetailsWrapper.isVaultItemAdministrator()) {
            return new VerdictWrapper(PolicyEnum.ALLOW);
        }

        return new ResourcePoliciesEvaluation(permissionResourceDaoWrapper).evaluate(requestDetailsWrapper, resource);
    }

    private VerdictWrapper validateVaultAdministrator(RequestDetailsWrapper requestDetailsWrapper) {
        if (requestDetailsWrapper.isVaultAdministrator()) {
            return new VerdictWrapper(PolicyEnum.ALLOW);
        }

        VerdictWrapper verdictWrapper = new VerdictWrapper(PolicyEnum.DENY);
        verdictWrapper.setErrorMessage(FhirVaultConstant.ERROR_MESSAGE_PRINCIPLE_ACCESS_POLICY);
        return verdictWrapper;
    }

    private VerdictWrapper getDenyPrincipleVerdictWrapper() {
        VerdictWrapper verdictWrapper = new VerdictWrapper(PolicyEnum.DENY);
        verdictWrapper.setErrorMessage(FhirVaultConstant.ERROR_MESSAGE_PRINCIPLE_ACCESS_POLICY);
        return verdictWrapper;
    }
}
