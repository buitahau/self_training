package swiss.owt.fhir.vault.util;

import ca.uhn.fhir.rest.server.interceptor.auth.IAuthRule;
import ca.uhn.fhir.rest.server.interceptor.auth.RuleBuilder;

import java.util.List;

public class IAuthRuleUtil {

    private IAuthRuleUtil() {
    }

    public static List<IAuthRule> buildRulesToAllowAll() {
        return new RuleBuilder()
                .allowAll()
                .build();
    }
}
