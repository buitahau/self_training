package swiss.owt.fhir.vault.util;

import ca.uhn.fhir.rest.api.server.RequestDetails;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import org.apache.commons.lang3.StringUtils;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.dto.FhirClaimDto;
import swiss.owt.fhir.vault.exception.FhirVaultException;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class JWTTokenUtil {

    public static FhirClaimDto parsingJwtToken(RequestDetails requestDetails) {
        try {
            String jwtToken = getToken(requestDetails);
            JWTClaimsSet jwtClaimsSet = getJWTClaimSet(jwtToken);
            return getFhirClaim(jwtClaimsSet);
        } catch (ParseException e) {
            throw new FhirVaultException("Error in parsing jwt", e);
        }
    }

    private static FhirClaimDto getFhirClaim(JWTClaimsSet jwtClaimsSet) throws ParseException {
        FhirClaimDto jwtDto = new FhirClaimDto();
        jwtDto.setAccountUrn(jwtClaimsSet.getStringClaim("cara:accountUrn"));
        List<String> scopes = Arrays.stream(
            Optional.ofNullable(jwtClaimsSet.getStringClaim("scope")).orElse("").split(" ")
        ).toList();
        jwtDto.setScope(scopes);
        jwtDto.setCaraRoles(jwtClaimsSet.getStringListClaim("cara:roles"));
        jwtDto.setClaimsSet(jwtClaimsSet);
        return jwtDto;
    }

    private static boolean isValidScope(String scope) {
        if (StringUtils.isBlank(scope)) {
            return false;
        }
        return scope.startsWith(FhirVaultConstant.PREFIX_NAMESPACE_SCOPE);
    }

    private static JWTClaimsSet getJWTClaimSet(String jwtToken) throws ParseException {
        JWT jwt = JWTParser.parse(jwtToken);
        return jwt.getJWTClaimsSet();
    }

    private static String getToken(RequestDetails theRequestDetails) {
        return theRequestDetails.getHeader("Authorization").replace("Bearer ", "");
    }
}
