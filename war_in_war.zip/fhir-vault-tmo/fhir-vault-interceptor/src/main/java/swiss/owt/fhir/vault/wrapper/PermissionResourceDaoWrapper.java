package swiss.owt.fhir.vault.wrapper;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import org.hl7.fhir.r5.model.Coding;
import org.hl7.fhir.r5.model.Permission;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.validation.PermissionValidation;

import java.util.*;

public class PermissionResourceDaoWrapper {

    private final IFhirResourceDao<Permission> permissionResourceDao;

    private final RequestDetails theRequestDetails;

    private boolean isFetched = false;

    private final Map<String, List<Permission>> transactionalPermissions = new HashMap<>();

    private final Map<String, List<Permission>> consentPermissions = new HashMap<>();

    public PermissionResourceDaoWrapper(IFhirResourceDao<Permission> permissionResourceDao,
                                        RequestDetails theRequestDetails) {

        this.permissionResourceDao = permissionResourceDao;
        this.theRequestDetails = theRequestDetails;
    }

    public List<Permission> getTransactionalPermissions(String namespace) {
        if (!isFetched) {
            fetchPermissions();
        }
        return transactionalPermissions.get(namespace);
    }

    public List<Permission> getConsentPermissions(String namespace) {
        if (!isFetched) {
            fetchPermissions();
        }
        return consentPermissions.get(namespace);
    }

    private void fetchPermissions() {
        SearchParameterMap searchParameterMap = new SearchParameterMap();
        IBundleProvider bundle = permissionResourceDao.search(searchParameterMap, theRequestDetails);
        bundle.getAllResources()
                .stream()
                .filter(Objects::nonNull)
                .map(IBaseResourceWrapper::new)
                .filter(IBaseResourceWrapper::isResourceAccessPolicy)
                .forEach(iBaseResourceWrapper -> {
                    Permission permission = (Permission) iBaseResourceWrapper.getOriginResource();
                    if (!PermissionValidation.isValid(permission)) {
                        return;
                    }
                    String namespace = iBaseResourceWrapper.getNamespace();
                    if (isTransactional(permission)) {
                        transactionalPermissions.computeIfAbsent(namespace, k -> new ArrayList<>());
                        transactionalPermissions.get(namespace).add(permission);
                    } else if (isConsent(permission)) {
                        consentPermissions.computeIfAbsent(namespace, k -> new ArrayList<>());
                        consentPermissions.get(namespace).add(permission);
                    }
                });
        isFetched = true;
    }

    private boolean isTransactional(Permission permission) {
        return permission.getMeta().getTag(
                FhirVaultConstant.PERMISSION_KIND,
                FhirVaultConstant.TRANSACTIONAL_CODE
        ) != null;
    }

    private boolean isConsent(Permission permission) {
        return permission
                .getMeta()
                .getTag()
                .stream()
                .anyMatch(coding -> isPermissionKind(coding, FhirVaultConstant.CONSENT_CODE));
    }

    private boolean isPermissionKind(Coding coding, String code) {
        return FhirVaultConstant.PERMISSION_KIND.equals(coding.getSystem()) && code.equals(coding.getCode());
    }
}
