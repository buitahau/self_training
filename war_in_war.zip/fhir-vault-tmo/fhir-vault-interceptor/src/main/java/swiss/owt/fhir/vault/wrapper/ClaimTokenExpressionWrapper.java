package swiss.owt.fhir.vault.wrapper;

import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.enumeration.QueryOperation;
import swiss.owt.fhir.vault.enumeration.SpecialCharacter;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.ComparisonQueryOperation;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.impl.EqualityQueryOperation;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.impl.ExistenceQueryOperation;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.impl.InclusionQueryOperation;
import swiss.owt.fhir.vault.evaluation.expression.operation.activity.impl.StartWithQueryOperation;

public class ClaimTokenExpressionWrapper {

    protected String expression;

    protected ComparisonQueryOperation comparisonQueryOperation;

    protected String claimName;

    public ClaimTokenExpressionWrapper(String expression) {
        this.expression = expression;
        this.setClaimName();
        this.setOperation();
    }

    public void setClaimName() {
        this.claimName = expression.substring(FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION.length() + 1
                , expression.indexOf(SpecialCharacter.QUESTION_MARKS.getSymbol()));
    }

    public String getClaimName() {
        return claimName;
    }

    public void setOperation() {
        String paramOfExpression = expression
                .substring(expression.indexOf(SpecialCharacter.QUESTION_MARKS.getSymbol()) + 1)
                .toUpperCase();

        if (paramOfExpression.startsWith(QueryOperation.EXIST.name())) {
            comparisonQueryOperation = new ExistenceQueryOperation();
            return;
        }
        if (paramOfExpression.startsWith(QueryOperation.EQUAL.name())) {
            comparisonQueryOperation = new EqualityQueryOperation();
            return;
        }
        if (paramOfExpression.startsWith(QueryOperation.INCLUDE.name())) {
            comparisonQueryOperation = new InclusionQueryOperation();
            return;
        }
        if (paramOfExpression.startsWith(QueryOperation.STARTWITH.name())) {
            comparisonQueryOperation = new StartWithQueryOperation();
        }
    }

    public ComparisonQueryOperation getComparisonQueryOperation() {
        return comparisonQueryOperation;
    }

    public String getExpectedValue() {
        int indexOfEqualSymbol = expression.indexOf(SpecialCharacter.EQUAL.getSymbol());
        if (indexOfEqualSymbol < 0) {
            return "";
        }

        return expression.substring(indexOfEqualSymbol + 1);
    }
}
