package swiss.owt.fhir.vault.evaluation.expression.operation.activity;

import java.util.List;

public class ContextQueryOperation {
    private ComparisonQueryOperation comparisonQueryOperation;

    public void setComparisonQueryOperation(ComparisonQueryOperation comparisonQueryOperation) {
        this.comparisonQueryOperation = comparisonQueryOperation;
    }

    public boolean execute(String expectValue, List<String> actualValue) {
        return comparisonQueryOperation.compare(expectValue, actualValue);
    }

}
