package swiss.owt.fhir.vault.exception;

public class FhirVaultException extends RuntimeException {

    public FhirVaultException() {
        super();
    }

    public FhirVaultException(String message) {
        super(message);
    }

    public FhirVaultException(String message, Throwable cause) {
        super(message, cause);
    }
}
