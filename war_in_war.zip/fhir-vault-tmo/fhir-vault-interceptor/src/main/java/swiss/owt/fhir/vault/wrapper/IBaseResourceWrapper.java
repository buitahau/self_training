package swiss.owt.fhir.vault.wrapper;

import org.apache.commons.lang3.Validate;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Bundle;
import org.hl7.fhir.r5.model.Permission;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.util.ResourceUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class IBaseResourceWrapper {

    protected IBaseResource iBaseResource;

    public IBaseResourceWrapper(IBaseResource iBaseResource) {
        Validate.notNull(iBaseResource);
        this.iBaseResource = iBaseResource;
    }

    public List<IBaseResource> getResources() {
        if (iBaseResource == null) {
            return new ArrayList<>();
        }
        if (isBundle()) {
            return parseToBundle().getEntry()
                    .stream()
                    .map(Bundle.BundleEntryComponent::getResource)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        }

        return new ArrayList<>(Arrays.asList(iBaseResource));
    }

    public Bundle parseToBundle() {
        return (Bundle) iBaseResource;
    }

    public IBaseResource getFinalResponseResource() {
        return iBaseResource;
    }

    public IBaseResource getOriginResource() {
        return iBaseResource;
    }

    public boolean isBundle() {
        if (iBaseResource == null) {
            return false;
        }
        return iBaseResource.getClass().getSimpleName().equals("Bundle");
    }

    public boolean isResourceAccessPolicy() {
        return (iBaseResource instanceof Permission) && hasProfileResourceAccessPolicy();
    }

    public boolean hasProfileResourceAccessPolicy() {
        return iBaseResource.getMeta().getProfile()
                .stream()
                .anyMatch(profile -> FhirVaultConstant.CARA_RESOURCE_ACCESS_POLICY.equalsIgnoreCase(profile.getValue()));
    }

    public String getNamespace() {
        return ResourceUtil.getNamespace(iBaseResource);
    }
}
