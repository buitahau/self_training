package swiss.owt.fhir.vault.evaluation.namespace;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.impl.NamespacePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static swiss.owt.fhir.vault.evaluation.namespace.NamespacePoliciesEvaluationHelper.*;
import static swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper.*;

public class NamespacePoliciesEvaluationForRoleReaderTest {
    private final NamespacePoliciesEvaluation namespacePoliciesEvaluation = new NamespacePoliciesEvaluation();

    @Test
    @DisplayName("30.Business scenario #5")
    public void givenPatientB_whenPerformReadOrVReadOrHistoryOfInstanceActionInSCPOfPatientB_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getReadAndVReadAndHistoryInstanceOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("31.Business scenario #5")
    public void givenPatientB_whenPerformUpdateOrPatchOrUpdateOfInstanceActionInSCPOfPatientB_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getUpdateAndPatchAndDeleteInstanceOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("32.Business scenario #5")
    public void givenPatientB_whenPerformSearchOrHistoryOfTypeActionInSCPOfPatientB_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getSearchAndHistoryTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("33.Business scenario #5")
    public void givenPatientB_whenPerformCreateOfTypeActionInSCPOfPatientB_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), RestOperationTypeEnum.CREATE, resource);

        assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
    }

    @Test
    @DisplayName("34.Business scenario #5")
    public void givenPatientB_whenPerformAnyOperationOfSystemActionInSCPOfPatientB_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnySystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("35.Business scenario #8")
    public void givenPractitionerB_whenPerformReadOrVReadOrHistoryOfInstanceActionInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getReadAndVReadAndHistoryInstanceOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("36.Business scenario #8")
    public void givenPractitionerB_whenPerformUpdateOrPatchOrUpdateOfInstanceActionInSCPOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getUpdateAndPatchAndDeleteInstanceOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientB(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("37.Business scenario #8")
    public void givenPractitionerB_whenPerformSearchOrHistoryOfTypeActionInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getSearchAndHistoryTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("38.Business scenario #8")
    public void givenPractitionerB_whenPerformCreateOfTypeActionInSCPOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB(), RestOperationTypeEnum.CREATE, resource);

        assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
    }

    @Test
    @DisplayName("39.Business scenario #8")
    public void givenPractitionerB_whenPerformAnyOperationOfSystemActionInSCPOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnySystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("40.Business scenario #8")
    public void givenPractitionerB_whenPerformReadOrVReadOrHistoryOfInstanceActionInSCPOfPatientB_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getReadAndVReadAndHistoryInstanceOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }
}
