package swiss.owt.fhir.vault.evaluation.vault_administrator;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Patient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.FhirVaultPoliciesEvaluation;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.wrapper.PermissionResourceDaoWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

public class PoliciesEvaluationTest {
    public final String PATIENT_URL = "/Patient";
    private final String FHIR_VAULT_ID = "fhir/";
    private FhirVaultPoliciesEvaluation fhirVaultPoliciesEvaluation;
    private RequestDetailsWrapper requestDetailsWrapper;
    private IBaseResource resource;
    public final String CARA_AUTH_X = "cara:" + PoliciesEvaluationHelper.NAMESPACE.AUTHX.name().toLowerCase();
    public final String CARA_SCP = "cara:" + PoliciesEvaluationHelper.NAMESPACE.SCP.name().toLowerCase();

    @BeforeEach
    void init() {
        requestDetailsWrapper = new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalA());
        fhirVaultPoliciesEvaluation = new FhirVaultPoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));
        resource = new Patient();
        resource.getMeta().addTag().setCode(CARA_AUTH_X).setSystem(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM);
    }

    @Test
    @DisplayName("The User has only Vault Administrator role in execute Partition Operation")
    void givenVaultAdministrator_whenActionPartitionOperation_thenAccessAllowed() {
        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        for (String partitionOperation : FhirVaultConstant.PARTITIONING_PATHS) {
            requestDetailsWrapper.getTheRequestDetails().setRequestPath(FHIR_VAULT_ID + partitionOperation);

            VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(
                    requestDetailsWrapper, resource);
            assertTrue(verdictWrapper.isAllow());
        }
    }

    @Test
    @DisplayName("The User has only Vault Administrator role in execute Patient Operation")
    void givenVaultAdministrator_whenActionAPatientOperation_thenAccessDenied() {
        requestDetailsWrapper.getTheRequestDetails().setRequestPath(FHIR_VAULT_ID + PATIENT_URL);
        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, resource);
        assertTrue(verdictWrapper.isDeny());
    }

    @Test
    @DisplayName("The User has only Vault Item Administrator role in execute Partition Operation")
    void givenVaultItemAdministrator_whenActionPartitionPatientOperation_thenAccessDenied() {
        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        for (String partitionOperation : FhirVaultConstant.PARTITIONING_PATHS) {
            requestDetailsWrapper.getTheRequestDetails().setRequestPath(FHIR_VAULT_ID + partitionOperation);

            VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(
                    requestDetailsWrapper, resource);
            assertTrue(verdictWrapper.isDeny());
        }
    }

    @Test
    @DisplayName("The User has only Vault Item Administrator role in execute Patient Operation")
    void givenVaultItemAdministrator_whenActionAPatientOperation_thenAccessAllowed() {
        RequestDetails theRequestDetails = requestDetailsWrapper.getTheRequestDetails();
        theRequestDetails.setRequestPath(FHIR_VAULT_ID + PATIENT_URL);
        theRequestDetails.setRestOperationType(RestOperationTypeEnum.READ);
        theRequestDetails.setResource(resource);

        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, resource);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("The User has Vault Administrator role and Vault Item Administrator in execute Partition Operation")
    void givenVaultAdministratorAndVaultItemAdministrator_whenActionPartitionOperation_thenAccessAllowed() {
        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR,
                FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        for (String partitionOperation : FhirVaultConstant.PARTITIONING_PATHS) {
            requestDetailsWrapper.getTheRequestDetails().setRequestPath(FHIR_VAULT_ID + partitionOperation);

            VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(
                    requestDetailsWrapper, resource);
            assertTrue(verdictWrapper.isAllow());
        }
    }

    @Test
    @DisplayName("The User has Vault Administrator role and Vault Item Administrator in execute Patient Operation")
    void givenVaultAdministratorAndVaultItemAdministrator_whenActionPatientOperation_thenAccessAllowed() {
        RequestDetails theRequestDetails = requestDetailsWrapper.getTheRequestDetails();
        theRequestDetails.setRequestPath(FHIR_VAULT_ID + PATIENT_URL);
        theRequestDetails.setRestOperationType(RestOperationTypeEnum.READ);
        theRequestDetails.setResource(resource);

        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR,
                FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, resource);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("The User has Vault Administrator role and Vault Item Administrator in execute Patient Operation which does not match namespace")
    void givenVaultAdministratorAndVaultItemAdministrator_whenActionPatientOperationNotMatchNamespace_thenAccessDenied() {
        RequestDetails theRequestDetails = requestDetailsWrapper.getTheRequestDetails();
        theRequestDetails.setRequestPath(FHIR_VAULT_ID + PATIENT_URL);
        theRequestDetails.setRestOperationType(RestOperationTypeEnum.READ);

        requestDetailsWrapper.getClaim().setCaraRoles(List.of(
                FhirVaultConstant.ROLE_VAULT_ADMINISTRATOR,
                FhirVaultConstant.ROLE_VAULT_ITEM_ADMINISTRATOR,
                FhirVaultConstant.ROLE_SERVICE_ACCOUNT));

        resource.getMeta().getTag(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM, CARA_AUTH_X).setCode(CARA_SCP);

        VerdictWrapper verdictWrapper = fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, resource);
        assertTrue(verdictWrapper.isDeny());
    }

    private PermissionResourceDaoWrapper mockPermissionResourceDaoWrapper(RequestDetails requestDetails) {
        return new PermissionResourceDaoWrapper(mockPermissionResourceDao(), requestDetails);
    }

    private IFhirResourceDao mockPermissionResourceDao() {
        return mock(IFhirResourceDao.class);
    }
}
