package swiss.owt.fhir.vault.evaluation.wrapper;

import org.apache.commons.collections4.CollectionUtils;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Bundle;
import org.hl7.fhir.r5.model.Patient;
import org.hl7.fhir.r5.model.Resource;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.wrapper.ResponseObjectWrapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ResponseObjectWrapperTest {

    @Test
    @DisplayName("Response is single resource, deny it, result is Forbidden")
    public void givenSingleResponse_whenDeny_thenResultIsForbidden() {
        IBaseResource response = mockSingleResponse();
        ResponseObjectWrapper responseObjectWrapper = new ResponseObjectWrapper(response);

        List<IBaseResource> denyResources = List.of(response);

        responseObjectWrapper.eliminateDenyResources(denyResources);

        List<IBaseResource> allowResources = responseObjectWrapper.getResources();

        assertTrue(!responseObjectWrapper.isBundle() && CollectionUtils.isEmpty(allowResources));
    }

    @Test
    @DisplayName("Response is single resource, no deny, result is Allow")
    public void givenSingleResponse_whenDeny_thenResultIsAllow() {
        IBaseResource response = mockSingleResponse();
        ResponseObjectWrapper responseObjectWrapper = new ResponseObjectWrapper(response);

        List<IBaseResource> denyResources = List.of();

        responseObjectWrapper.eliminateDenyResources(denyResources);

        List<IBaseResource> allowResources = responseObjectWrapper.getResources();

        assertFalse(!responseObjectWrapper.isBundle() && CollectionUtils.isEmpty(allowResources));
    }

    @Test
    @DisplayName("Response is bundle with 3 resources, deny 1 resource, result is a bundle with 2 remaining resources")
    public void givenBundleResponse_whenDenyOneResource_thenResultIs2RemainingResources() {
        int originNumberOfEntries = 3;

        IBaseResource response = mockBundle(originNumberOfEntries);

        ResponseObjectWrapper responseObjectWrapper = new ResponseObjectWrapper(response);

        List<IBaseResource> denyResources = List.of(mockResource("p" + 0));

        responseObjectWrapper.eliminateDenyResources(denyResources);

        List<IBaseResource> allowResources = responseObjectWrapper.getResources();

        assertFalse(!responseObjectWrapper.isBundle() && CollectionUtils.isEmpty(allowResources));

        assertEquals(originNumberOfEntries - denyResources.size(),
                ((Bundle) responseObjectWrapper.getFinalResponseResource())
                        .getEntry()
                        .stream()
                        .filter(entry -> entry.getResource() != null)
                        .count());
    }

    @Test
    @DisplayName("Response is bundle with 3 resources, deny all, result is an empty bundle")
    public void givenBundleResponse_whenDenyAll_thenResultIsEmptyBundle() {
        int originNumberOfEntries = 3;

        IBaseResource response = mockBundle(originNumberOfEntries);

        ResponseObjectWrapper responseObjectWrapper = new ResponseObjectWrapper(response);

        List<IBaseResource> denyResources = List.of(mockResource("p" + 0), mockResource("p" + 1),
                mockResource("p" + 2));

        responseObjectWrapper.eliminateDenyResources(denyResources);

        List<IBaseResource> allowResources = responseObjectWrapper.getResources();

        assertFalse(!responseObjectWrapper.isBundle() && CollectionUtils.isEmpty(allowResources));

        assertEquals(0, ((Bundle) responseObjectWrapper
                .getFinalResponseResource())
                .getEntry()
                .stream()
                .filter(entry -> entry.getResource() != null)
                .count());
    }

    private IBaseResource mockSingleResponse() {
        return new Patient();
    }

    private IBaseResource mockBundle(int numberOfEntries) {
        Bundle bundle = new Bundle();
        for (int i = 0; i < numberOfEntries; i++) {
            bundle.getEntry().add(new Bundle.BundleEntryComponent().setResource(mockResource("p" + i)));
        }
        bundle.setTotal(numberOfEntries);
        return bundle;
    }

    private Resource mockResource(String id) {
        Patient patient = new Patient();
        patient.getIdElement().setValue(id);
        return patient;
    }
}
