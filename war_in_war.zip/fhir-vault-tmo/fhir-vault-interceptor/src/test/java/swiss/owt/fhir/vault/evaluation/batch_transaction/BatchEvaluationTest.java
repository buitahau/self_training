package swiss.owt.fhir.vault.evaluation.batch_transaction;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Bundle;
import org.hl7.fhir.r5.model.Patient;
import org.hl7.fhir.r5.model.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.interceptor.FhirVaultPoliciesInterceptor;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

public class BatchEvaluationTest {

    private static final String VAULT_ID = "john";

    private FhirVaultPoliciesInterceptor fhirVaultPoliciesInterceptor;

    @BeforeEach
    private void beforeEach() {
        fhirVaultPoliciesInterceptor = new FhirVaultPoliciesInterceptor(mockPermissionResourceDao());
    }

    private IFhirResourceDao mockPermissionResourceDao() {
        return mock(IFhirResourceDao.class);
    }

    @Test
    @DisplayName("Allow all batch requests")
    public void setAllowRuleForBatchRequestTest() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addBatchOperation(requestDetails);

        Bundle bundle = mockBatchBundle();
        requestDetails.setResource(bundle);

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.buildRuleList(requestDetails));
    }

    @Test
    @DisplayName("Validate responses of batch request")
    public void validateResponsesOfBatchRequestTest() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addBatchOperation(requestDetails);

        Bundle bundle = mockBatchBundle();
        requestDetails.setResource(bundle);

        IBaseResource responseObject = mockPatientInAuthxNamespace();
        ResponseDetails responseDetails = new ResponseDetails();

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.hookOutgoingResponse(
                requestDetails, responseObject, null, responseDetails));

        assertEquals(responseObject.getIdElement().getIdPart(),
                responseDetails.getResponseResource().getIdElement().getIdPart());
    }

    @Test
    @DisplayName("No validate if not found resource")
    public void noValidateIfNotFoundResource() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addBatchOperation(requestDetails);

        Bundle bundle = mockBatchBundle();
        requestDetails.setResource(bundle);

        Bundle responseObject = mockBundleResponse();
        addResourceToBundle(responseObject, mockPatientInAuthxNamespace());
        addResourceNotFoundToBundle(responseObject);

        ResponseDetails responseDetails = new ResponseDetails();

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.hookOutgoingResponse(
                requestDetails, responseObject, null, responseDetails));

        assertEquals(((Bundle) responseDetails.getResponseResource()).getEntry().size(),
                responseObject.getEntry().size());
    }

    @Test
    @DisplayName("Eliminate responses if Invalid")
    public void eliminateResponsesIfInValid() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addBatchOperation(requestDetails);

        Bundle bundle = mockBatchBundle();
        requestDetails.setResource(bundle);

        Bundle responseObject = mockBundleResponse();
        addResourceToBundle(responseObject, mockPatientInAuthxNamespace());
        addResourceToBundle(responseObject, mockPatientInOtherNamespace());
        int beforeSize = responseObject.getEntry().size();

        ResponseDetails responseDetails = new ResponseDetails();

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.hookOutgoingResponse(
                requestDetails, responseObject, null, responseDetails));

        assertEquals(beforeSize - 1,
                ((Bundle) responseDetails.getResponseResource())
                        .getEntry()
                        .stream()
                        .filter(entry -> entry.getResource() != null)
                        .count());
    }

    @Test
    @DisplayName("Eliminate all resources if invalid")
    public void eliminateAllResources() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addBatchOperation(requestDetails);

        Bundle bundle = mockBatchBundle();
        requestDetails.setResource(bundle);

        Bundle responseObject = mockBundleResponse();
        addResourceToBundle(responseObject, mockPatientInOtherNamespace());
        addResourceNotFoundToBundle(responseObject);

        ResponseDetails responseDetails = new ResponseDetails();

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.hookOutgoingResponse(
                requestDetails, responseObject, null, responseDetails));

        assertEquals(0,
                ((Bundle) responseDetails.getResponseResource())
                        .getEntry()
                        .stream()
                        .filter(entry -> entry.getResource() != null)
                        .count());
    }

    private void addResourceNotFoundToBundle(Bundle bundle) {
        Bundle.BundleEntryResponseComponent notFound = new Bundle.BundleEntryResponseComponent();
        notFound.setStatus("404 Not Found");
        bundle.getEntry().add(new Bundle.BundleEntryComponent().setResponse(notFound));
    }

    private void addResourceToBundle(Bundle bundle, Resource resource) {
        bundle.getEntry().add(new Bundle.BundleEntryComponent().setResource(resource));
    }

    private Bundle mockBundleResponse() {
        Bundle bundle = new Bundle();
        return bundle;
    }

    private void addBatchOperation(RequestDetails requestDetails) {
        requestDetails.setRequestPath(VAULT_ID);
        requestDetails.setTenantId(VAULT_ID);
        requestDetails.setRestOperationType(RestOperationTypeEnum.BATCH);
        requestDetails.setRequestType(RequestTypeEnum.POST);
    }

    private Bundle mockBatchBundle() {
        Bundle bundle = new Bundle();
        bundle.setType(Bundle.BundleType.BATCH);

        bundle.getEntry().add(
                new Bundle.BundleEntryComponent().setRequest(
                        new Bundle.BundleEntryRequestComponent()
                                .setMethod(Bundle.HTTPVerb.GET)
                                .setUrl("/Patient/1")));
        return bundle;
    }

    private Resource mockPatientInAuthxNamespace() {
        return mockPatientInAuthxNamespace(UUID.randomUUID().toString());
    }

    private Resource mockPatientInOtherNamespace() {
        return mockPatientInOtherNamespace(UUID.randomUUID().toString(), "cara:abc");
    }

    private Resource mockPatientInAuthxNamespace(String id) {
        Resource resource = new Patient();
        resource.setId(id);
        PoliciesEvaluationHelper.addAuthxNamespace(resource);
        return resource;
    }

    private Resource mockPatientInOtherNamespace(String id, String namespace) {
        Resource resource = new Patient();
        resource.setId(id);
        resource.getMeta().addTag().setCode(namespace).setSystem(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM);
        return resource;
    }
}
