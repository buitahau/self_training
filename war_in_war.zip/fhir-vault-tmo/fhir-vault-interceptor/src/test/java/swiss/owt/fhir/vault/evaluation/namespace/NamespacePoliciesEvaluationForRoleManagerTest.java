package swiss.owt.fhir.vault.evaluation.namespace;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.impl.NamespacePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static swiss.owt.fhir.vault.evaluation.namespace.NamespacePoliciesEvaluationHelper.*;
import static swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper.*;

public class NamespacePoliciesEvaluationForRoleManagerTest {

    private final NamespacePoliciesEvaluation namespacePoliciesEvaluation = new NamespacePoliciesEvaluation();

    @Test
    @DisplayName("4.Business scenario #4")
    public void givenPatientA_whenPerformAnyActionInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("5.Business scenario #9")
    public void givenPractitionerC_whenPerformAnyActionOnInstanceOrTypeLevelInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("8.Business scenario #2")
    public void givenTechnicalA_whenPerformReadWriteInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfTechnicalA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }
}
