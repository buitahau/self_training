package swiss.owt.fhir.vault.evaluation.namespace;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.r5.model.Permission;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.impl.NamespacePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("Resource Access Policy Test")
public class NamespaceAccessPolicyTest {

    private final NamespacePoliciesEvaluation namespacePoliciesEvaluation = new NamespacePoliciesEvaluation();

    @Test
    @DisplayName("Manager performs action to RAP, then access granted")
    public void givenPractitionerC_whenPerformsReadRAP_thenAccessGranted() {
        Permission permission = mockScpRAP();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Manager performs action to regular Permission, then access granted")
    public void givenPractitionerC_whenPerformsReadRegularPermission_thenAccessGranted() {
        Permission permission = mockScpPermission();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setResource(permission);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Contributor performs action to RAP, then access deny")
    public void givenPractitionerA_whenPerformsReadRAP_thenAccessDeny() {
        Permission permission = mockScpRAP();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertFalse(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Contributor performs action to regular Permission, then access granted")
    public void givenPractitionerA_whenPerformsReadRegularPermission_thenAccessGranted() {
        Permission permission = mockScpPermission();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setResource(permission);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Reader performs action to RAP, then access deny")
    public void givenPractitionerB_whenPerformsReadRAP_thenAccessDeny() {
        Permission permission = mockScpRAP();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertFalse(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Reader performs action to regular Permission, then access granted")
    public void givenPractitionerB_whenPerformsRegularPermission_thenAccessDeny() {
        Permission permission = mockScpPermission();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setResource(permission);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertTrue(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("User without role in namespace performs action to RAP, then access deny")
    public void givenCollaborator_whenPerformsReadRAP_thenAccessDeny() {
        Permission permission = mockScpRAP();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfCaraCollaboration());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertFalse(verdictWrapper.isAllow());
    }

    @Test
    @DisplayName("User without role in namespace performs action to regular Permission, then access deny")
    public void givenCollaborator_whenPerformsReadRegularPermission_thenAccessDeny() {
        Permission permission = mockScpPermission();
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfCaraCollaboration());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        VerdictWrapper verdictWrapper = namespacePoliciesEvaluation.evaluate(requestDetailsWrapper, permission);
        assertFalse(verdictWrapper.isAllow());
    }

    private Permission mockScpRAP() {
        Permission permission = new Permission();
        permission.getMeta().addTag().setCode("cara:scp").setSystem(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM);
        permission.getMeta().addProfile(FhirVaultConstant.CARA_RESOURCE_ACCESS_POLICY);
        return permission;
    }

    private Permission mockScpPermission() {
        Permission permission = new Permission();
        permission.getMeta().addTag().setCode("cara:scp").setSystem(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM);
        return permission;
    }
}
