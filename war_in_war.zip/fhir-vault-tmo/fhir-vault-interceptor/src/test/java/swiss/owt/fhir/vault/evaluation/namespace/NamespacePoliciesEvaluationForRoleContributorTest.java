package swiss.owt.fhir.vault.evaluation.namespace;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.impl.NamespacePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static swiss.owt.fhir.vault.evaluation.namespace.NamespacePoliciesEvaluationHelper.*;
import static swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper.*;

public class NamespacePoliciesEvaluationForRoleContributorTest {
    private final NamespacePoliciesEvaluation namespacePoliciesEvaluation = new NamespacePoliciesEvaluation();

    @Test
    @DisplayName("12.Business scenario #4")
    public void givenPatientA_whenPerformAnyInstanceActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("13.Business scenario #4")
    public void givenPatientA_whenPerformBatchOrTransactionOfSystemActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getBatchAndTransactionSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("14.Business scenario #4")
    public void givenPatientA_whenPerformHistoryOrSearchOfSystemActionInAuthXOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getHistoryAndSearchSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPatientA(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("15.Business scenario #7")
    public void givenPractitionerA_whenPerformAnyInstanceActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("18.Business scenario #7")
    public void givenPractitionerA_whenPerformBatchOrTransactionOfSystemActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getBatchAndTransactionSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("19.Business scenario #7")
    public void givenPractitionerA_whenPerformHistoryOrSearchOfSystemActionInAuthXOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getHistoryAndSearchSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("20.Business scenario #7")
    public void givenPractitionerA_whenPerformAnyInstanceOrTypeActionInAuthXOfPatientC_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_C_IDENTIFIER, LINK_SYSTEM);
        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("21.Business scenario #7")
    public void givenPractitionerA_whenPerformBatchOrTransactionOfSystemActionInAuthXOfPatientC_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_C_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getBatchAndTransactionSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("21.Business scenario #4")
    public void givenPractitionerA_whenPerformHistoryOrSearchOfSystemActionInAuthXOfPatientC_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_C_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getHistoryAndSearchSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("22.Business scenario #10")
    public void givenCaregiverA_whenPerformAnyInstanceOrTypeActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfCaregiverA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("23.Business scenario #10")
    public void givenCaregiverA_whenPerformAnyInstanceOrTypeActionInAuthXOfPatientB_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfCaregiverA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("24.Business scenario #10")
    public void givenCaregiverA_whenPerformBatchOrTransactionOfSystemActionInAuthXOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getBatchAndTransactionSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfCaregiverA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("24.Business scenario #10")
    public void givenCaregiverA_whenPerformHistoryOrSearchOfSystemActionInAuthXOfPatientA_thenAccessDenied() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.AUTHX.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getHistoryAndSearchSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfCaregiverA(), restOperationTypeEnum, resource);

            assertFalse(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("25.Business scenario #13")
    public void representativeA_whenPerformAnyInstanceOrTypeActionInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfRepresentativeA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("26.Business scenario #13")
    public void representativeA_whenPerformAnyInstanceOrTypeActionInSCPOfPatientB_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_B_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getAnyInstanceOrTypeOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfRepresentativeA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }

    @Test
    @DisplayName("26.Business scenario #13")
    public void representativeA_whenPerformBatchOrTransactionOfSystemActionInSCPOfPatientA_thenAccessGranted() {
        IBaseResource resource = setUpIBaseResource(PLATFORM.CARA.name(), NAMESPACE.SCP.name(),
                PoliciesEvaluationHelper.PATIENT_A_IDENTIFIER, LINK_SYSTEM);

        for (RestOperationTypeEnum restOperationTypeEnum : getBatchAndTransactionSystemOperations()) {
            RequestDetailsWrapper requestDetailsWrapper = setUpRequestDetailsWrapper(
                    PoliciesEvaluationHelper.mockRequestDetailOfRepresentativeA(), restOperationTypeEnum, resource);

            assertTrue(isAllowEvaluation(namespacePoliciesEvaluation, requestDetailsWrapper, resource));
        }
    }
}
