package swiss.owt.fhir.vault.evaluation.vault_administrator;

import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Coding;
import org.hl7.fhir.r5.model.Patient;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.FhirVaultPoliciesEvaluation;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Partition Operation Test")
public class PartitionOperationTest {

    @Test
    @DisplayName("[No.1] [Business scenarios #1, #3]")
    public void givenTechnicalUserA_whenPerformPartitionOperations_thenAccessGranted() {
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalA());

        FhirVaultPoliciesEvaluation fhirVaultPoliciesEvaluation = new FhirVaultPoliciesEvaluation(null);

        for (String path : mockPartitionPaths()) {
            requestDetailsWrapper.getTheRequestDetails().setRequestPath(path);

            assertTrue(fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, null).isAllow());
        }
    }

    @Test
    @DisplayName("[No.2] [Business scenarios #1]")
    public void givenTechnicalUserA_whenPerformCreatePatient_thenAccessDenied() {
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalA());
        requestDetailsWrapper.getTheRequestDetails().setRequestPath("Patient");
        requestDetailsWrapper.getTheRequestDetails().setRequestType(RequestTypeEnum.POST);

        IBaseResource patientA = mockFhirResource(PoliciesEvaluationHelper.NAMESPACE.AUTHX.name());

        FhirVaultPoliciesEvaluation fhirVaultPoliciesEvaluation = new FhirVaultPoliciesEvaluation(null);

        assertFalse(fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, patientA).isAllow());
    }

    @Test
    @DisplayName("[No.3] [Business scenarios #2]")
    public void givenTechnicalUserB_whenPerformPartitionOperations_thenAccessDenied() {
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB());

        FhirVaultPoliciesEvaluation fhirVaultPoliciesEvaluation = new FhirVaultPoliciesEvaluation(null);

        for (String path : mockPartitionPaths()) {
            requestDetailsWrapper.getTheRequestDetails().setRequestPath(path);

            assertFalse(fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, null).isAllow());
        }
    }

    @Test
    @DisplayName("[No.4] [Business scenarios #2, #3]")
    public void givenTechnicalUserB_whenPerformCreatePatient_thenAccessGranted() {
        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB());
        requestDetailsWrapper.getTheRequestDetails().setRequestPath("Patient");
        requestDetailsWrapper.getTheRequestDetails().setRequestType(RequestTypeEnum.POST);
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.CREATE);

        IBaseResource patientA = mockFhirResource(PoliciesEvaluationHelper.NAMESPACE.AUTHX.name());
        requestDetailsWrapper.getTheRequestDetails().setResource(patientA);

        FhirVaultPoliciesEvaluation fhirVaultPoliciesEvaluation = new FhirVaultPoliciesEvaluation(null);

        assertTrue(fhirVaultPoliciesEvaluation.validatePolicies(requestDetailsWrapper, patientA).isAllow());
    }

    private List<String> mockPartitionPaths() {
        return List.of("partition-management-create-partition",
                "partition-management-update-partition",
                "partition-management-delete-partition",
                "partition-management-read-partition",
                "partition-management-list-partitions");
    }

    private IBaseResource mockFhirResource(String namespace) {
        Patient resource = new Patient();
        resource.getMeta().addTag(
                new Coding()
                        .setSystem(FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM)
                        .setCode(buildNameSpace(namespace)));
        return resource;
    }

    private String buildNameSpace(String namespace) {
        return (PoliciesEvaluationHelper.PLATFORM.CARA.name() + ":" + namespace).toLowerCase();
    }
}
