package swiss.owt.fhir.vault.evaluation.resource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.expression.ClaimTokenExpressionEvaluation;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClaimTokenExpressionEvaluationTest {
    private RequestDetailsWrapper requestDetailsWrapper;

    @BeforeEach
    void init() {
        requestDetailsWrapper = new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
    }

    @Test
    @DisplayName("Case truly existence expression")
    void givenValidExistenceExpression_whenPerformCheckClaimTokenExpression_thenReturnTrue() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/accountUrn?exist";
        assertTrue(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case failed existence expression")
    void givenInValidExistenceExpression_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/something?exist";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case truly equality expression")
    void givenValidEqualityExpression_whenPerformCheckClaimTokenExpression_thenReturnTrue() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/accountUrn?equal=urn:cara:account:patient-a";
        assertTrue(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case failed equality expression")
    void givenInValidEqualityExpression_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/accountUrn?equal=something";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case failed startWith expression")
    void givenInValidStartWithExpression_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?startWith=caragroup_";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case truly startWith expression")
    void givenValidStartWithExpression_whenPerformCheckClaimTokenExpression_thenReturnTrue() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?startWith=group_";
        assertTrue(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case truly inclusion expression")
    void givenValidInclusionExpression_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?include=group_a";
        assertTrue(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case failed inclusion expression")
    void givenInValidInclusionExpression_whenPerformCheckClaimTokenExpression_thenReturnTrue() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?include=something";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case undefined expression")
    void givenInValidExpression_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?something=group_a";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case unexpected input value")
    void givenValidExpressionButUnexpectedInputValue_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/group?include=";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case unexpected url prefix")
    void givenInValidPrefixExpressionUrl_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = "fake-token://claim" + "/group?include=";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case empty url")
    void givenEmptyExpressionUrl_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = "";
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case null url")
    void givenNullExpressionUrl_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = null;
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case not contain question marks url")
    void givenNoQuestionMarksExpressionUrl_whenPerformCheckClaimTokenExpression_thenReturnFalse() {
        String expression = FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION;
        assertFalse(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }

    @Test
    @DisplayName("Case multiple url")
    void givenExpressionUrls_whenPerformCheckClaimTokenExpression_thenReturnTrue() {
        String expression =
                FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/groups?include=group_a"
                        + ";" + FhirVaultConstant.PREFIX_TOKEN_CLAIM_EXPRESSION + "/accountUrn?include=urn:cara:account:patient-a";
        assertTrue(ClaimTokenExpressionEvaluation.evaluate(requestDetailsWrapper, expression));
    }
}
