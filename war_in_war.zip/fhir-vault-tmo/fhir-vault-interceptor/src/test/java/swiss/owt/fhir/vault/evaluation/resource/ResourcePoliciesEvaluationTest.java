package swiss.owt.fhir.vault.evaluation.resource;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.SimpleBundleProvider;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.CareTeam;
import org.hl7.fhir.r5.model.Patient;
import org.hl7.fhir.r5.model.Permission;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluate;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.evaluation.impl.ResourcePoliciesEvaluation;
import swiss.owt.fhir.vault.wrapper.PermissionResourceDaoWrapper;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

public class ResourcePoliciesEvaluationTest {

    private static final String HENRY_ID = "henry";

    private static final String LUCY = "lucy";

    private static final String EVE_ID = "eve";

    private static final String ALICE_ID = "alice";

    private IFhirResourceDao permissionResourceDao;

    @BeforeEach
    private void beforeEach() {
        permissionResourceDao = mock(IFhirResourceDao.class);
    }

    @Test
    @DisplayName("[No.42] Business scenario #2")
    void givenPatientA_whenPerformAnyActionInSCPTeamMember_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfHenry()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(HENRY_ID);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    private SimpleBundleProvider mockRAPPermissionsOfHenry() {
        return new SimpleBundleProvider(List.of(
                mockSCPTransactionalRAPPermissionOfHenry()));
    }

    private Permission mockSCPTransactionalRAPPermissionOfHenry() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity
                , "token://claim/groups?include=group_a");
        PoliciesEvaluationHelper.addActions(activity, List.of("read", "vread", "search"));
        return permission;
    }

    @Test
    @DisplayName("[No.42] Business scenario #2")
    void givenPatientA_whenPerformAnyActionInSCPTeamMember_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfHenry()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(HENRY_ID);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("[No.9] Business scenario #7")
    void givenPractitionerA_whenPerformUpdateInSCPTeamMember_thenAccessAllowed() {
        doReturn(mockRAPPermissionsOfLucy()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(LUCY);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    private SimpleBundleProvider mockRAPPermissionsOfLucy() {
        return new SimpleBundleProvider(List.of(
                mockSCPTransactionalRAPPermissionOfLucy()));
    }

    private Permission mockSCPTransactionalRAPPermissionOfLucy() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule1 = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule1);

        Permission.RuleActivityComponent activityOfRule1 = new Permission.RuleActivityComponent();
        rule1.addActivity(activityOfRule1);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activityOfRule1,
                List.of(
                        "token://claim/glnUrn?equal=urn:cara:gln:practitioner-b",
                        "token://claim/accountUrn?equal=urn:cara:account:technical-user-b",
                        "token://claim/cara:roles?include=TECHNICAL_USER;token://claim/glnUrns?include=urn:cara:gln:technical-user-b"));
        PoliciesEvaluationHelper.addActions(activityOfRule1, List.of("read", "vread", "search"));

        Permission.RuleComponent rule2 = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule2);

        Permission.RuleActivityComponent activityOfRule2 = new Permission.RuleActivityComponent();
        rule2.addActivity(activityOfRule2);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activityOfRule2,
                List.of(
                        "token://claim/glnUrn?equal=urn:cara:gln:practitioner-a",
                        "token://claim/accountUrn?equal=urn:cara:account:technical-user-a",
                        "token://claim/cara:roles?include=TECHNICAL_USER;token://claim/glnUrns?include=urn:cara:gln:technical-user-a"));
        PoliciesEvaluationHelper.addAction(activityOfRule2, "update");
        return permission;
    }

    @Test
    void givenPractitionerA_whenPerformReadInSCPTeamMember_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfLucy()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(LUCY);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenTechnicalB_whenPerformReadInSCPTeamMember_thenAccessAllowed() {
        doReturn(mockRAPPermissionsOfLucy()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(LUCY);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenTechnicalB_whenPerformUpdateInSCPTeamMember_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfLucy()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(LUCY);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenTechnicalC_whenPerformUpdateInSCPTeamMember_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfLucy()).when(permissionResourceDao).search(any(SearchParameterMap.class),
                any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfTechnicalC());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(LUCY);

        IBaseResource resource = mockCareTeamInSCPNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Denied when no Resource Access Policies")
    void givenPatientA_whenNoResourceAccessPolicies_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfHenry()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(EVE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    private SimpleBundleProvider mockRAPPermissionsOfEve() {
        return new SimpleBundleProvider(List.of(
                mockAuthxTransactionalRAPPermissionOfEve(),
                mockAuthxConsentRAPPermissionOfEve()));
    }

    private Permission mockAuthxConsentRAPPermissionOfEve() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:authx", FhirVaultConstant.CONSENT_CODE);

        Permission.RuleComponent rule1 = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule1);

        PoliciesEvaluationHelper.addFhirPath(rule1, "%resource is CareTeam");

        Permission.RuleActivityComponent activityOfRule1 = new Permission.RuleActivityComponent();
        rule1.addActivity(activityOfRule1);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activityOfRule1, "token://claim/glnUrn?equal=urn:cara:gln:patient-a");
        PoliciesEvaluationHelper.addActions(activityOfRule1, List.of("read", "search"));

        Permission.RuleComponent rule2 = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule2);

        PoliciesEvaluationHelper.addFhirPath(rule2, "%resource is CareTeam");

        Permission.RuleActivityComponent activityOfRule2 = new Permission.RuleActivityComponent();
        rule2.addActivity(activityOfRule2);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activityOfRule2, "token://claim/groups?startWith=group_");
        PoliciesEvaluationHelper.addActions(activityOfRule2, List.of("vread", "search"));
        return permission;
    }

    private Permission mockAuthxTransactionalRAPPermissionOfEve() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:authx", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        PoliciesEvaluationHelper.addFhirPath(rule, "%resource is CareTeam");

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(
                activity, "token://claim/accountUrn?exist");
        PoliciesEvaluationHelper.addActions(activity, List.of("read", "vread", "search"));
        return permission;
    }

    @Test
    void givenPatientA_whenReadCareTeamOfEveOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfEve()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        // eve
        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenPatientA_whenVReadCareTeamOfEveOnAuthxNamespace_AndMatchStartWithExpression_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfEve()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.VREAD);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(EVE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenPatientA_whenVReadPatientProfileOfEveOnAuthxNamespace_AndMatchStartWithExpression_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfEve()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.VREAD);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(EVE_ID);

        IBaseResource resource = mockPatientInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    void givenPatientA_whenReadPatientProfileOfEveOnAuthxNamespace_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfEve()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPatientA());
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(EVE_ID);

        IBaseResource resource = mockPatientInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow observers to read care team member")
    void givenPractitionerC_whenReadCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    private SimpleBundleProvider mockRAPPermissionsOfAlice() {
        return new SimpleBundleProvider(List.of(
                mockAuthxTransactionalRAPPermissionOfAlice()));
    }

    private SimpleBundleProvider mockRAPPermissionsOfAlice(List<String> actions) {
        return new SimpleBundleProvider(List.of(
                mockAuthxTransactionalRAPPermissionOfAlice(actions)));
    }

    private Permission mockAuthxTransactionalRAPPermissionOfAlice() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:authx", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        PoliciesEvaluationHelper.addFhirPath(rule, "%resource is CareTeam");

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity, "token://claim/accountUrn?exist");
        PoliciesEvaluationHelper.addActions(activity, List.of("read", "vread", "search", "create", "update", "delete",
                "patch"));
        return permission;
    }

    private Permission mockAuthxTransactionalRAPPermissionOfAlice(List<String> actions) {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:authx", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        PoliciesEvaluationHelper.addFhirPath(rule, "%resource is CareTeam");

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(
                activity, "token://claim/accountUrn?exist");
        PoliciesEvaluationHelper.addActions(activity, actions);
        return permission;
    }

    @Test
    @DisplayName("Deny observers to update care team member")
    void givenPractitionerC_whenUpdateCareTeamOfAliceOnAuthxNamespace_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfAlice(List.of("read", "vread", "search", "create", "delete", "patch")))
                .when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Deny observers to delete care team member")
    void givenPractitionerC_whenDeleteCareTeamOfAliceOnAuthxNamespace_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfAlice(List.of("read", "vread", "search", "create", "update", "patch")))
                .when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerC());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.DELETE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow contributor to read care team member")
    void givenPractitionerB_whenReadCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow contributor to update care team member")
    void givenPractitionerB_whenUpdateCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Deny contributor to delete care team member")
    void givenPractitionerB_whenDeleteCareTeamOfAliceOnAuthxNamespace_thenAccessDenied() {
        doReturn(mockRAPPermissionsOfAlice(List.of("read", "vread", "search", "create", "update", "patch")))
                .when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerB());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.DELETE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertFalse(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow manager to read care team member")
    void givenPractitionerA_whenReadCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.READ);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow manager to update care team member")
    void givenPractitionerA_whenUpdateCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.UPDATE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    @Test
    @DisplayName("Allow manager to delete care team member")
    void givenPractitionerA_whenDeleteCareTeamOfAliceOnAuthxNamespace_thenAccessGranted() {
        doReturn(mockRAPPermissionsOfAlice()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetailsWrapper requestDetailsWrapper =
                new RequestDetailsWrapper(PoliciesEvaluationHelper.mockRequestDetailOfPractitionerA());
        addMockOperation(requestDetailsWrapper, RestOperationTypeEnum.DELETE);
        requestDetailsWrapper.getTheRequestDetails().setTenantId(ALICE_ID);

        IBaseResource resource = mockCareTeamInAuthxNamespace();
        requestDetailsWrapper.getTheRequestDetails().setResource(resource);

        PoliciesEvaluate resourcePoliciesEvaluation = new ResourcePoliciesEvaluation(
                mockPermissionResourceDaoWrapper(requestDetailsWrapper.getTheRequestDetails()));

        VerdictWrapper resourceVerdictWrapper = resourcePoliciesEvaluation.evaluate(requestDetailsWrapper, resource);
        assertTrue(resourceVerdictWrapper.isAllow());
    }

    private void addMockOperation(RequestDetailsWrapper requestDetailsWrapper, RestOperationTypeEnum operationType) {
        requestDetailsWrapper.getTheRequestDetails().setRestOperationType(operationType);
    }

    private IBaseResource mockCareTeamInSCPNamespace() {
        IBaseResource resource = new CareTeam();
        PoliciesEvaluationHelper.addSCPNamespace(resource);
        return resource;
    }

    private IBaseResource mockCareTeamInAuthxNamespace() {
        IBaseResource resource = new CareTeam();
        PoliciesEvaluationHelper.addAuthxNamespace(resource);
        return resource;
    }

    private IBaseResource mockPatientInAuthxNamespace() {
        IBaseResource resource = new Patient();
        PoliciesEvaluationHelper.addAuthxNamespace(resource);
        return resource;
    }

    private PermissionResourceDaoWrapper mockPermissionResourceDaoWrapper(RequestDetails requestDetails) {
        return new PermissionResourceDaoWrapper(permissionResourceDao, requestDetails);
    }
}
