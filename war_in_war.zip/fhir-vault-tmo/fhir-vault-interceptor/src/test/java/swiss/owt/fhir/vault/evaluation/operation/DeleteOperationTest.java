package swiss.owt.fhir.vault.evaluation.operation;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.SimpleBundleProvider;
import ca.uhn.fhir.rest.server.exceptions.ForbiddenOperationException;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Patient;
import org.hl7.fhir.r5.model.Permission;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.interceptor.FhirVaultPoliciesInterceptor;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

public class DeleteOperationTest {

    private static final String VAULT_ID = "delete-partition";

    private FhirVaultPoliciesInterceptor fhirVaultPoliciesInterceptor;

    private IFhirResourceDao permissionResourceDao;

    @BeforeEach
    private void beforeEach() {
        permissionResourceDao = mock(IFhirResourceDao.class);
        fhirVaultPoliciesInterceptor = new FhirVaultPoliciesInterceptor(permissionResourceDao);
    }

    @Test
    @DisplayName("Test grant access when deleting valid resource")
    public void givenPatientA_whenPerformDeleteValidResource_thenAccessGranted() {
        doReturn(mockRAPPermissions()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfPatientA();
        addDeleteOperation(requestDetails);

        String resourceId = UUID.randomUUID().toString();
        IBaseResource resource = mockScpPatient(resourceId);
        requestDetails.setRequestPath(VAULT_ID + "/Patient/" + resourceId);

        assertDoesNotThrow(() -> fhirVaultPoliciesInterceptor.resourceDeleted(resource, requestDetails));
    }

    @Test
    @DisplayName("Test grant deny when deleting invalid resource")
    public void givenPatientA_whenPerformDeleteValidResource_thenDeny() {
        doReturn(mockRAPPermissionsWithoutDeleteOperation()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfPatientA();
        addDeleteOperation(requestDetails);

        String resourceId = UUID.randomUUID().toString();
        IBaseResource resource = mockScpPatient(resourceId);
        requestDetails.setRequestPath(VAULT_ID + "/Patient/" + resourceId);

        assertThrows(ForbiddenOperationException.class,
                () -> fhirVaultPoliciesInterceptor.resourceDeleted(resource, requestDetails));
    }

    private SimpleBundleProvider mockRAPPermissionsWithoutDeleteOperation() {
        return new SimpleBundleProvider
                (List.of(mockSCPTransactionalRAPPermission(List.of("read", "vread", "search", "create", "update"))));
    }

    private IBaseResource mockScpPatient(String resourceId) {
        IBaseResource resource = new Patient();
        resource.setId(resourceId);
        PoliciesEvaluationHelper.addSCPNamespace(resource);
        return resource;
    }

    private void addDeleteOperation(RequestDetails requestDetails) {
        requestDetails.setRestOperationType(RestOperationTypeEnum.DELETE);
        requestDetails.setRequestType(RequestTypeEnum.DELETE);
    }

    private Permission mockSCPTransactionalRAPPermission(List<String> actions) {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity, "token://claim/accountUrn?exist");
        PoliciesEvaluationHelper.addActions(activity, actions);

        return permission;
    }

    private Permission mockSCPConsentRAPPermission(List<String> actions) {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.CONSENT_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity, "token://claim/groups?startWith=group_");
        PoliciesEvaluationHelper.addActions(activity, actions);
        return permission;
    }

    private SimpleBundleProvider mockRAPPermissions() {
        return new SimpleBundleProvider(
                List.of(mockSCPTransactionalRAPPermission(
                        List.of("read", "vread", "search", "create", "update", "delete"))));
    }
}
