package swiss.owt.fhir.vault.evaluation.namespace;

import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r5.model.Patient;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluate;
import swiss.owt.fhir.vault.wrapper.RequestDetailsWrapper;
import swiss.owt.fhir.vault.wrapper.VerdictWrapper;

import java.util.Arrays;

public class NamespacePoliciesEvaluationHelper {

    public static final String LINK_SYSTEM = FhirVaultConstant.FHIR_VAULT_NAMESPACE_SYSTEM;

    public static RestOperationTypeEnum[] getAnyOperations() {
        return new RestOperationTypeEnum[]{
                RestOperationTypeEnum.READ,
                RestOperationTypeEnum.VREAD,
                RestOperationTypeEnum.UPDATE,
                RestOperationTypeEnum.PATCH,
                RestOperationTypeEnum.DELETE,
                RestOperationTypeEnum.HISTORY_INSTANCE,
                RestOperationTypeEnum.CREATE,
                RestOperationTypeEnum.SEARCH_TYPE,
                RestOperationTypeEnum.HISTORY_TYPE,
                RestOperationTypeEnum.BATCH,
                RestOperationTypeEnum.TRANSACTION,
                RestOperationTypeEnum.HISTORY_SYSTEM,
                RestOperationTypeEnum.SEARCH_SYSTEM
        };
    }

    public static RestOperationTypeEnum[] getAnySystemOperations() {
        return Arrays
                .stream(getAnyOperations())
                .filter(RestOperationTypeEnum::isSystemLevel)
                .toArray(RestOperationTypeEnum[]::new);
    }

    public static RestOperationTypeEnum[] getAnyInstanceOperations() {
        return Arrays
                .stream(getAnyOperations())
                .filter(RestOperationTypeEnum::isInstanceLevel)
                .toArray(RestOperationTypeEnum[]::new);
    }

    public static RestOperationTypeEnum[] getAnyInstanceOrTypeOperations() {
        return Arrays.stream(getAnyOperations()).filter(item -> item.isInstanceLevel()
                || item.isTypeLevel()).toArray(RestOperationTypeEnum[]::new);
    }

    public static RestOperationTypeEnum[] getBatchAndTransactionSystemOperations() {
        return new RestOperationTypeEnum[]{RestOperationTypeEnum.BATCH, RestOperationTypeEnum.TRANSACTION};
    }

    public static RestOperationTypeEnum[] getHistoryAndSearchSystemOperations() {
        return new RestOperationTypeEnum[]{RestOperationTypeEnum.HISTORY_SYSTEM,
                RestOperationTypeEnum.SEARCH_SYSTEM};
    }

    public static RestOperationTypeEnum[] getReadAndVReadAndHistoryInstanceOperations() {
        return new RestOperationTypeEnum[]{RestOperationTypeEnum.HISTORY_INSTANCE, RestOperationTypeEnum.READ,
                RestOperationTypeEnum.VREAD};
    }

    public static RestOperationTypeEnum[] getUpdateAndPatchAndDeleteInstanceOperations() {
        return new RestOperationTypeEnum[]{RestOperationTypeEnum.UPDATE, RestOperationTypeEnum.PATCH,
                RestOperationTypeEnum.DELETE};
    }

    public static RestOperationTypeEnum[] getSearchAndHistoryTypeOperations() {
        return new RestOperationTypeEnum[]{RestOperationTypeEnum.SEARCH_TYPE, RestOperationTypeEnum.HISTORY_TYPE};
    }

    public static IBaseResource setUpIBaseResource(String platform, String namespace, String id, String link) {
        IBaseResource resource = new Patient();
        resource.setId(id);
        final String code = platform.toLowerCase() + ":" + namespace.toLowerCase();
        resource.getMeta().addTag().setCode(code).setSystem(link);

        return resource;
    }

    public static RequestDetailsWrapper setUpRequestDetailsWrapper(RequestDetails requestDetails,
                                                                   RestOperationTypeEnum restOperationTypeEnum,
                                                                   IBaseResource resource) {

        requestDetails.setRestOperationType(restOperationTypeEnum);
        requestDetails.setResource(resource);
        return new RequestDetailsWrapper(requestDetails);
    }

    public static boolean isAllowEvaluation(PoliciesEvaluate policiesEvaluate,
                                            RequestDetailsWrapper requestDetailsWrapper, IBaseResource ibaseResource) {

        VerdictWrapper verdictWrapper = policiesEvaluate.evaluate(requestDetailsWrapper, ibaseResource);
        return verdictWrapper.isAllow();
    }
}
