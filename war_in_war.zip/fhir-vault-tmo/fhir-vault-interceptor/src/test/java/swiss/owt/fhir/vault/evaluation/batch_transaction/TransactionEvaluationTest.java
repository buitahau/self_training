package swiss.owt.fhir.vault.evaluation.batch_transaction;

import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.rest.api.RequestTypeEnum;
import ca.uhn.fhir.rest.api.RestOperationTypeEnum;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.SimpleBundleProvider;
import ca.uhn.fhir.rest.server.exceptions.ForbiddenOperationException;
import org.hl7.fhir.r5.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import swiss.owt.fhir.vault.constant.FhirVaultConstant;
import swiss.owt.fhir.vault.evaluation.PoliciesEvaluationHelper;
import swiss.owt.fhir.vault.interceptor.FhirVaultPoliciesInterceptor;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

public class TransactionEvaluationTest {

    private static final String VAULT_ID = "john";

    private FhirVaultPoliciesInterceptor fhirVaultPoliciesInterceptor;

    private IFhirResourceDao permissionResourceDao;

    @BeforeEach
    private void beforeEach() {
        permissionResourceDao = mock(IFhirResourceDao.class);
        fhirVaultPoliciesInterceptor = new FhirVaultPoliciesInterceptor(permissionResourceDao);
    }

    @Test
    @DisplayName("Case Authx Vault Item Administrator post valid bundle, then granted")
    public void givenAuthxVaultItemAdministrator_whenPerformValidBundle_thenAccessGranted() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addAuthxPatientWithPostMethodToEntry(bundle);
        addAuthxResourcePermissionWithPostMethodToEntry(bundle);

        assertDoesNotThrow(processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case Authx Vault Item Administrator post invalid bundle (has one scp resource), then deny")
    public void givenAuthxVaultItemAdministrator_whenPerformInvalidBundle_thenAccessDeny() {
        RequestDetails requestDetails = PoliciesEvaluationHelper.mockRequestDetailOfTechnicalB();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addAuthxPatientWithPostMethodToEntry(bundle);
        addSCPResourcePermissionWithPostMethodToEntry(bundle);

        assertThrows(ForbiddenOperationException.class, processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case manager post valid bundle(add resource), then granted")
    public void givenManager_whenAddResourceByBundle_thenAccessGranted() {
        doReturn(mockRAPPermissions()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetails requestDetails = mockSCPManager();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithPostMethodToEntry(bundle);

        assertDoesNotThrow(processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case manager post valid bundle(update resource), then granted")
    public void givenManager_whenUpdateResourceByBundle_thenAccessGranted() {
        doReturn(mockRAPPermissions()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetails requestDetails = mockSCPManager();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithPutMethodToEntry(bundle);

        assertDoesNotThrow(processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case manager post valid bundle(delete resource), then granted")
    public void givenManager_whenDeleteResourceByBundle_thenAccessGranted() {
        doReturn(mockRAPPermissions()).when(permissionResourceDao)
                .search(any(SearchParameterMap.class), any(RequestDetails.class));

        RequestDetails requestDetails = mockSCPManager();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithDeleteMethodToEntry(bundle);

        assertDoesNotThrow(processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case reader post valid bundle(add resource), then deny")
    public void givenReader_whenAddResourceByBundle_thenAccessDeny() {
        RequestDetails requestDetails = mockSCPReader();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithPostMethodToEntry(bundle);

        assertThrows(ForbiddenOperationException.class, processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case reader post valid bundle(update resource), then deny")
    public void givenReader_whenUpdateResourceByBundle_thenAccessDeny() {
        RequestDetails requestDetails = mockSCPReader();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithPutMethodToEntry(bundle);

        assertThrows(ForbiddenOperationException.class, processEvaluation(requestDetails));
    }

    @Test
    @DisplayName("Case reader post valid bundle(delete resource), then deny")
    public void givenReader_whenDeleteResourceByBundle_thenAccessDeny() {
        RequestDetails requestDetails = mockSCPReader();
        addTransactionOperation(requestDetails);

        Bundle bundle = mockTransactionBundle();
        requestDetails.setResource(bundle);

        addSCPPatientWithDeleteMethodToEntry(bundle);

        assertThrows(ForbiddenOperationException.class, processEvaluation(requestDetails));
    }

    private Permission mockSCPTransactionalRAPPermission() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.TRANSACTIONAL_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity, "token://claim/accountUrn?exist");
        PoliciesEvaluationHelper.addActions(activity, List.of("read", "vread", "search", "create", "update", "delete"));

        return permission;
    }

    private Permission mockSCPConsentRAPPermission() {
        Permission permission = PoliciesEvaluationHelper.mockRAPPermission(
                "cara:scp", FhirVaultConstant.CONSENT_CODE);

        Permission.RuleComponent rule = PoliciesEvaluationHelper.mockRule();
        permission.getRule().add(rule);

        PoliciesEvaluationHelper.addFhirPath(rule, "%resource is Patient");
        PoliciesEvaluationHelper.addFhirPath(rule, "%resource is Permission");

        Permission.RuleActivityComponent activity = new Permission.RuleActivityComponent();
        rule.addActivity(activity);

        PoliciesEvaluationHelper.addRuleActivityPrincipal(activity, "token://claim/groups?startWith=group_");
        PoliciesEvaluationHelper.addActions(activity, List.of("read", "vread", "search", "create", "update", "delete"));
        return permission;
    }

    private SimpleBundleProvider mockRAPPermissions() {
        return new SimpleBundleProvider(List.of(mockSCPTransactionalRAPPermission(), mockSCPConsentRAPPermission()));
    }

    private RequestDetails mockSCPReader() {
        return PoliciesEvaluationHelper.mockRequestDetailOfPatientB();
    }

    private RequestDetails mockSCPManager() {
        return PoliciesEvaluationHelper.mockRequestDetailOfPatientA();
    }

    private Executable processEvaluation(RequestDetails requestDetails) {
        return () -> fhirVaultPoliciesInterceptor.incomingRequestPreHandled(requestDetails, null);
    }

    private void addAuthxResourcePermissionWithPostMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockResourcePermissionInAuthxNamespace(id), "Permission/" + id);
    }

    private void addAuthxPatientWithPostMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockPatientInAuthxNamespace(id), "Patient/" + id);
    }

    private void addSCPPatientWithPostMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockPatientInSCPNamespace(id), "Patient/" + id);
    }

    private void addSCPPatientWithPutMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockPatientInSCPNamespace(id), "Patient/" + id, Bundle.HTTPVerb.PUT);
    }

    private void addSCPPatientWithDeleteMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockPatientInSCPNamespace(id), "Patient/" + id, Bundle.HTTPVerb.DELETE);
    }

    private void addSCPResourcePermissionWithPostMethodToEntry(Bundle bundle) {
        String id = UUID.randomUUID().toString();
        addToEntry(bundle, mockResourcePermissionInSCPNamespace(id), "Permission/" + id);
    }

    private void addToEntry(Bundle bundle, Resource resource, String fullUrl) {
        addToEntry(bundle, resource, fullUrl, Bundle.HTTPVerb.POST);
    }

    private void addToEntry(Bundle bundle, Resource resource, String fullUrl, Bundle.HTTPVerb httpVerb) {
        Bundle.BundleEntryComponent entry = new Bundle.BundleEntryComponent();
        bundle.getEntry().add(entry);
        entry.setFullUrl(fullUrl);
        entry.setResource(resource);
        entry.setRequest(
                new Bundle.BundleEntryRequestComponent()
                        .setMethod(httpVerb)
                        .setUrl(fullUrl));
    }

    private void addTransactionOperation(RequestDetails requestDetails) {
        requestDetails.setRequestPath(VAULT_ID);
        requestDetails.setTenantId(VAULT_ID);
        requestDetails.setRestOperationType(RestOperationTypeEnum.TRANSACTION);
        requestDetails.setRequestType(RequestTypeEnum.POST);
    }

    private Bundle mockTransactionBundle() {
        Bundle bundle = new Bundle();
        bundle.setType(Bundle.BundleType.TRANSACTION);
        return bundle;
    }

    private Resource mockPatientInAuthxNamespace(String id) {
        Resource resource = new Patient();
        resource.setId(id);
        PoliciesEvaluationHelper.addAuthxNamespace(resource);
        return resource;
    }

    private Resource mockResourcePermissionInAuthxNamespace(String id) {
        Resource resource = new Permission();
        resource.setId(id);
        PoliciesEvaluationHelper.addAuthxNamespace(resource);
        return resource;
    }

    private Resource mockPatientInSCPNamespace(String id) {
        Resource resource = new Patient();
        resource.setId(id);
        PoliciesEvaluationHelper.addSCPNamespace(resource);
        return resource;
    }

    private Resource mockResourcePermissionInSCPNamespace(String id) {
        Resource resource = new Permission();
        resource.setId(id);
        PoliciesEvaluationHelper.addSCPNamespace(resource);
        return resource;
    }
}
