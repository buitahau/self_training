#!/bin/bash

set -ex

HAPI_FHIR_VERSION="6.8.3"
URL="https://github.com/hapifhir/hapi-fhir-jpaserver-starter/archive/refs/tags/image/v${HAPI_FHIR_VERSION}.zip"
JPASERVER_STARTER_DIR="./hapi-fhir-jpaserver-starter"

if [ ! -d "$JPASERVER_STARTER_DIR" ]; then
  mkdir -p target
  curl -L $URL -o target/hapi-fhir-jpaserver-starter.zip
  unzip -o target/hapi-fhir-jpaserver-starter.zip -d target
  mv --force target/hapi-fhir-jpaserver-starter-* $JPASERVER_STARTER_DIR
fi

./mvnw -f $JPASERVER_STARTER_DIR/pom.xml clean install -DskipTests

./mvnw verify -DskipTests -Dfhir.version=$HAPI_FHIR_VERSION

docker build -t protector:develop .
